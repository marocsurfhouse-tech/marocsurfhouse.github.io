import { Link } from 'react-router';
import { Instagram, Facebook, Youtube, MapPin, Mail, Phone } from 'lucide-react';

const BerberPattern = () => (
  <svg
    className="w-full h-6 opacity-20"
    viewBox="0 0 400 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
  >
    {Array.from({ length: 20 }).map((_, i) => (
      <g key={i} transform={`translate(${i * 20}, 0)`}>
        <polygon points="10,2 18,12 10,22 2,12" stroke="currentColor" strokeWidth="1" fill="none" />
        <line x1="10" y1="2" x2="10" y2="22" stroke="currentColor" strokeWidth="0.5" />
        <line x1="2" y1="12" x2="18" y2="12" stroke="currentColor" strokeWidth="0.5" />
      </g>
    ))}
  </svg>
);

const WaPath = "M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z";

const WhatsAppIcon = ({ size = 28, color = "white" }: { size?: number; color?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill={color} width={size} height={size} aria-hidden="true">
    <path d={WaPath} />
  </svg>
);

export default function Footer() {
  const waUrl = "https://wa.me/212606461292?text=Bonjour%2C%20je%20suis%20int%C3%A9ress%C3%A9(e)%20par%20un%20pack%20surf%20%C3%A0%20Tamraght%20!";

  return (
    <>
      <footer className="bg-[hsl(var(--surface-dark))] text-white/80">
        <div className="text-white/30 px-6 pt-8">
          <BerberPattern />
        </div>

        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
            {/* Brand */}
            <div className="md:col-span-2">
              <Link to="/">
                <img
                  src="/airo-assets/images/logo/horizontal/dark"
                  alt="Maroc Surf House"
                  className="block h-auto max-h-10 w-auto max-w-[160px] object-contain mb-4"
                />
              </Link>
              <p className="text-sm leading-relaxed text-white/60 max-w-xs">
                Ton camp de surf à Tamraght, au coeur de la côte atlantique marocaine. Vagues, soleil et aventure t'attendent.
              </p>
              <div className="flex gap-4 mt-5">
                <a href="#" aria-label="Instagram" className="text-white/50 hover:text-primary transition-colors">
                  <Instagram size={20} />
                </a>
                <a href="#" aria-label="Facebook" className="text-white/50 hover:text-primary transition-colors">
                  <Facebook size={20} />
                </a>
                <a href="#" aria-label="YouTube" className="text-white/50 hover:text-primary transition-colors">
                  <Youtube size={20} />
                </a>
                <a href="#" aria-label="X (Twitter)" className="text-white/50 hover:text-primary transition-colors">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.73-8.835L1.254 2.25H8.08l4.253 5.622zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                  </svg>
                </a>
                <a href={waUrl} target="_blank" rel="noopener noreferrer" aria-label="WhatsApp" className="text-white/50 hover:text-primary transition-colors">
                  <WhatsAppIcon size={20} color="currentColor" />
                </a>
              </div>
            </div>

            {/* Navigation */}
            <div>
              <h3 className="text-white font-semibold text-sm uppercase tracking-widest mb-4">Navigation</h3>
              <nav aria-label="Liens footer" className="flex flex-col gap-2">
                {[
                  { label: 'Accueil', href: '/' },
                  { label: 'Packs Surf', href: '/packs' },
                  { label: 'Activités', href: '/activites' },
                  { label: 'À propos', href: '/a-propos' },
                  { label: 'Contact', href: '/contact' },
                ].map((link) => (
                  <Link key={link.href} to={link.href} className="text-sm text-white/60 hover:text-white transition-colors">
                    {link.label}
                  </Link>
                ))}
              </nav>
            </div>

            {/* Contact */}
            <div>
              <h3 className="text-white font-semibold text-sm uppercase tracking-widest mb-4">Contact</h3>
              <div className="flex flex-col gap-3">
                <div className="flex items-start gap-2 text-sm text-white/60">
                  <MapPin size={15} className="mt-0.5 shrink-0 text-primary" />
                  <span>Tamraght, Agadir-Ida-Ou-Tanane<br />Maroc</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-white/60">
                  <Mail size={15} className="shrink-0 text-primary" />
                  <a href="mailto:contact@marocsurfhouse.com" className="hover:text-white transition-colors">
                    contact@marocsurfhouse.com
                  </a>
                </div>
                <div className="flex items-center gap-2 text-sm text-white/60">
                  <Phone size={15} className="shrink-0 text-primary" />
                  <a href="tel:+212606461292" className="hover:text-white transition-colors">
                    +212 6 06 46 12 92
                  </a>
                </div>
                <div className="flex items-center gap-2 text-sm text-white/60">
                  <WhatsAppIcon size={15} color="#25D366" />
                  <a href={waUrl} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
                    WhatsApp
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-10 pt-6 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-white/40">
            <span>© {new Date().getFullYear()} Maroc Surf House — Tamraght, Maroc</span>
            <div className="flex gap-4">
              <Link to="/mentions-legales" className="hover:text-white/70 transition-colors">Mentions légales</Link>
              <Link to="/confidentialite" className="hover:text-white/70 transition-colors">Confidentialité</Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Bouton WhatsApp flottant */}
      <a
        href={waUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Nous contacter sur WhatsApp"
        className="fixed bottom-6 right-6 z-50 flex items-center justify-center w-14 h-14 rounded-full shadow-xl transition-transform duration-200 hover:scale-110"
        style={{ background: '#25D366' }}
      >
        <WhatsAppIcon size={28} color="white" />
      </a>
    </>
  );
}
