import { RouteObject } from 'react-router';
import { lazy } from 'react';
import HomePage from './pages/index';
import PacksPage from './pages/packs';
import ActivitesPage from './pages/activites';
import ContactPage from './pages/contact';
import PackDetailPage from './pages/pack-detail';
import AboutPage from './pages/about';
// Eager import so renderToString doesn't hit a Suspense boundary on 404 routes
// and abort to client rendering. The prod 404 page is tiny; the dev-tools
// variant stays lazy because it pulls in dev-only code we don't want in
// production bundles.
import ProdNotFoundPage from './pages/_404';

const NotFoundPage = ProdNotFoundPage;

export const routes: RouteObject[] = [
  {
    path: '/',
    element: <HomePage />,
  },
  {
    path: '/packs',
    element: <PacksPage />,
  },
  {
    path: '/activites',
    element: <ActivitesPage />,
  },
  {
    path: '/contact',
    element: <ContactPage />,
  },
  {
    path: '/a-propos',
    element: <AboutPage />,
  },
  {
    path: '/packs/:slug',
    element: <PackDetailPage />,
  },
  {
    id: 'airo-not-found',
    path: '*',
    element: <NotFoundPage />,
  },
];

// Types for type-safe navigation
export type Path = '/' | '/packs' | '/activites' | '/contact' | '/a-propos' | '/packs/:slug';

export type Params = Record<string, string | undefined>;
