import { z } from 'zod';
export const schemas = {
  pages: {
    home: z.object({
      "hero": z.object({
        "title": z.string(),
        "subtitle": z.string(),
        "cta": z.string(),
        "ctaHref": z.string()
      }),
      "packs": z.object({
        "heading": z.string(),
        "subheading": z.string(),
        "items": z.array(z.object({
          "id": z.string(),
          "name": z.string(),
          "duration": z.string(),
          "price": z.string(),
          "description": z.string(),
          "includes": z.array(z.string())
        }))
      }),
      "activities": z.object({
        "heading": z.string(),
        "subheading": z.string(),
        "items": z.array(z.object({
          "id": z.string(),
          "name": z.string(),
          "tagline": z.string(),
          "description": z.string()
        }))
      }),
      "whyUs": z.object({
        "heading": z.string(),
        "stats": z.array(z.object({
          "id": z.string(),
          "number": z.string(),
          "label": z.string()
        }))
      }),
      "cta": z.object({
        "heading": z.string(),
        "body": z.string(),
        "buttonLabel": z.string(),
        "buttonHref": z.string()
      })
    }),
    packs: z.object({
      "hero": z.object({
        "eyebrow": z.string(),
        "title": z.string(),
        "subtitle": z.string()
      }),
      "packs": z.array(z.object({
        "id": z.string(),
        "slug": z.string(),
        "name": z.string(),
        "tagline": z.string(),
        "duration": z.string(),
        "nights": z.string(),
        "meals": z.string(),
        "accommodation": z.string(),
        "level": z.string(),
        "season": z.string(),
        "price": z.string(),
        "priceOriginal": z.string(),
        "discount": z.string(),
        "currency": z.string(),
        "popular": z.boolean(),
        "badge": z.string(),
        "description": z.string(),
        "highlights": z.array(z.object({
          "id": z.string(),
          "icon": z.string(),
          "label": z.string()
        })),
        "includes": z.array(z.object({
          "id": z.string(),
          "text": z.string()
        })),
        "notIncluded": z.array(z.object({
          "id": z.string(),
          "text": z.string()
        }))
      })),
      "faq": z.array(z.object({
        "id": z.string(),
        "question": z.string(),
        "answer": z.string()
      })),
      "cta": z.object({
        "heading": z.string(),
        "sub": z.string(),
        "button": z.string()
      })
    }),
    activites: z.object({
      "hero": z.object({
        "title": z.string(),
        "subtitle": z.string()
      }),
      "intro": z.object({
        "heading": z.string(),
        "body": z.string()
      }),
      "activities": z.array(z.object({
        "id": z.string(),
        "name": z.string(),
        "tagline": z.string(),
        "duration": z.string(),
        "price": z.string(),
        "currency": z.string(),
        "difficulty": z.string(),
        "groupSize": z.string(),
        "description": z.string(),
        "highlights": z.array(z.string()),
        "bestFor": z.string()
      })),
      "note": z.object({
        "text": z.string()
      }),
      "cta": z.object({
        "heading": z.string(),
        "body": z.string(),
        "buttonLabel": z.string()
      })
    }),
    contact: z.object({
      "hero": z.object({
        "title": z.string(),
        "subtitle": z.string()
      }),
      "form": z.object({
        "heading": z.string(),
        "subheading": z.string(),
        "fields": z.object({
          "nameLabel": z.string(),
          "namePlaceholder": z.string(),
          "emailLabel": z.string(),
          "emailPlaceholder": z.string(),
          "phoneLabel": z.string(),
          "phonePlaceholder": z.string(),
          "packLabel": z.string(),
          "levelLabel": z.string(),
          "arrivalLabel": z.string(),
          "departureLabel": z.string(),
          "messageLabel": z.string(),
          "messagePlaceholder": z.string(),
          "submitLabel": z.string(),
          "sendingLabel": z.string(),
          "successHeading": z.string(),
          "successBody": z.string(),
          "errorLabel": z.string()
        })
      }),
      "info": z.object({
        "heading": z.string(),
        "address": z.string(),
        "email": z.string(),
        "phone": z.string(),
        "responseTime": z.string(),
        "hours": z.string()
      }),
      "social": z.object({
        "heading": z.string(),
        "instagram": z.string(),
        "facebook": z.string(),
        "youtube": z.string()
      })
    }),
    about: z.object({
      "hero": z.object({
        "eyebrow": z.string(),
        "title": z.string(),
        "subtitle": z.string()
      }),
      "story": z.object({
        "eyebrow": z.string(),
        "title": z.string(),
        "paragraphs": z.array(z.object({
          "id": z.string(),
          "text": z.string()
        }))
      }),
      "values": z.object({
        "eyebrow": z.string(),
        "title": z.string(),
        "items": z.array(z.object({
          "id": z.string(),
          "icon": z.string(),
          "title": z.string(),
          "description": z.string()
        }))
      }),
      "team": z.object({
        "eyebrow": z.string(),
        "title": z.string(),
        "members": z.array(z.object({
          "id": z.string(),
          "name": z.string(),
          "role": z.string(),
          "bio": z.string(),
          "image": z.string()
        }))
      }),
      "location": z.object({
        "eyebrow": z.string(),
        "title": z.string(),
        "description": z.string(),
        "details": z.array(z.object({
          "id": z.string(),
          "label": z.string(),
          "value": z.string()
        }))
      }),
      "cta": z.object({
        "title": z.string(),
        "subtitle": z.string(),
        "buttonPacks": z.string(),
        "buttonContact": z.string()
      })
    })
  },
  data: {
    pack_details: z.array(z.object({
      "id": z.string(),
      "slug": z.string(),
      "name": z.string(),
      "tagline": z.string(),
      "duration": z.string(),
      "nights": z.string(),
      "meals": z.string(),
      "accommodation": z.string(),
      "price": z.string(),
      "priceOriginal": z.string(),
      "discount": z.string(),
      "currency": z.string(),
      "level": z.string(),
      "season": z.string(),
      "heroAlt": z.string(),
      "intro": z.string(),
      "days": z.array(z.object({
        "id": z.string(),
        "label": z.string(),
        "title": z.string(),
        "slots": z.array(z.object({
          "id": z.string(),
          "time": z.string(),
          "activity": z.string()
        }))
      })),
      "includes": z.array(z.object({
        "id": z.string(),
        "text": z.string()
      })),
      "notIncluded": z.array(z.object({
        "id": z.string(),
        "text": z.string()
      })),
      "faq": z.array(z.object({
        "id": z.string(),
        "question": z.string(),
        "answer": z.string()
      }))
    }))
  },
  site: z.object({
    "packDetail": z.object({
      "slotMorning": z.string(),
      "slotAfternoon": z.string(),
      "slotEvening": z.string()
    })
  })
};
export type Schemas = typeof schemas;