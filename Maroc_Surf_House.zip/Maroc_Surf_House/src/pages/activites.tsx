import { Helmet } from '@dr.pogodin/react-helmet';
import { Link } from 'react-router';
import { motion } from 'motion/react';
import { ArrowRight, Clock, Users, Zap, Star } from 'lucide-react';
import { activites } from 'virtual:content';

// ─── Animation variants ───────────────────────────────────────────────────────
const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.55, ease: 'easeOut' as const } },
};
const stagger = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.14 } },
};

// ─── Image slots per activity id ─────────────────────────────────────────────
const activityImages: Record<string, string> = {
  'paradise-valley': '/airo-assets/images/pages/home/activite-paradise-valley',
  'timlaline':       '/airo-assets/images/pages/home/activite-timlaline',
  'imsouan':         '/airo-assets/images/pages/home/activite-imsouan',
};

// ─── Berber divider ───────────────────────────────────────────────────────────
function BerberDivider({ light = false }: { light?: boolean }) {
  return (
    <div className={`w-full overflow-hidden ${light ? 'text-white/15' : 'text-black/10'}`}>
      <svg viewBox="0 0 400 20" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-5" aria-hidden="true">
        {Array.from({ length: 20 }).map((_, idx) => (
          <g key={idx} transform={`translate(${idx * 20}, 0)`}>
            <polygon points="10,2 18,10 10,18 2,10" stroke="currentColor" strokeWidth="0.8" fill="none" />
            <line x1="10" y1="2" x2="10" y2="18" stroke="currentColor" strokeWidth="0.4" />
            <line x1="2" y1="10" x2="18" y2="10" stroke="currentColor" strokeWidth="0.4" />
          </g>
        ))}
      </svg>
    </div>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export default function ActivitesPage() {
  const siteUrl = 'https://marocsurfhouse.com';
  const pageUrl = `${siteUrl}/activites`;

  return (
    <>
      <Helmet>
        <title>Activités & Excursions — Maroc Surf House Tamraght</title>
        <meta
          name="description"
          content="Excursions depuis Tamraght : Paradise Valley, village berbère de Timlaline, village de pêcheurs d'Imsouan. À partir de 15€/personne. Transport inclus."
        />
        <link rel="canonical" href={pageUrl} />
        <meta property="og:title" content="Activités & Excursions — Maroc Surf House" />
        <meta property="og:description" content="Paradise Valley, Timlaline, Imsouan — explorez le Maroc authentique depuis notre camp de surf à Tamraght." />
        <meta property="og:url" content={pageUrl} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content={`${siteUrl}/og-image.svg`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:image" content={`${siteUrl}/og-image.svg`} />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@graph': [
            {
              '@type': 'WebPage',
              '@id': `${pageUrl}#webpage`,
              name: 'Activités & Excursions — Maroc Surf House',
              url: pageUrl,
              description: 'Paradise Valley, Timlaline, Imsouan — explorez le Maroc authentique depuis notre camp de surf à Tamraght.',
              isPartOf: { '@id': `${siteUrl}/#website` },
            },
            {
              '@type': 'BreadcrumbList',
              '@id': `${pageUrl}#breadcrumb`,
              itemListElement: [
                { '@type': 'ListItem', position: 1, name: 'Accueil', item: siteUrl },
                { '@type': 'ListItem', position: 2, name: 'Activités', item: pageUrl },
              ],
            },
          ],
        }).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main>
        {/* ── HERO ─────────────────────────────────────────────────────────── */}
        <section
          className="relative pt-36 pb-24 px-6 flex items-center justify-center overflow-hidden"
          style={{ background: 'hsl(var(--surface-dark))' }}
        >
          {/* Berber filigrane background */}
          <div className="absolute inset-0 opacity-5 pointer-events-none" aria-hidden="true">
            <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="berber-bg" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
                  <polygon points="20,4 36,20 20,36 4,20" stroke="white" strokeWidth="1" fill="none" />
                  <line x1="20" y1="4" x2="20" y2="36" stroke="white" strokeWidth="0.5" />
                  <line x1="4" y1="20" x2="36" y2="20" stroke="white" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#berber-bg)" />
            </svg>
          </div>

          <div className="relative z-10 text-center max-w-3xl mx-auto">
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-primary text-sm font-semibold tracking-widest uppercase mb-3"
            >
              Explorer le Maroc
            </motion.p>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.35 }}
              className="text-5xl md:text-6xl font-bold text-white mb-5"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              {activites.hero.title}
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="text-white/65 text-lg max-w-xl mx-auto"
            >
              {activites.hero.subtitle}
            </motion.p>
          </div>
        </section>

        {/* ── BERBER DIVIDER ───────────────────────────────────────────────── */}
        <div style={{ background: 'hsl(var(--surface-dark))' }}>
          <BerberDivider light />
        </div>

        {/* ── INTRO ────────────────────────────────────────────────────────── */}
        <section className="py-16 px-6" style={{ background: 'hsl(var(--sand))' }}>
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="max-w-2xl mx-auto text-center"
          >
            <h2
              className="text-3xl md:text-4xl font-bold mb-4"
              style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--surface-dark))' }}
            >
              {activites.intro.heading}
            </h2>
            <p className="text-base leading-relaxed" style={{ color: 'hsl(var(--surface-dark) / 0.65)' }}>
              {activites.intro.body}
            </p>
          </motion.div>
        </section>

        {/* ── BERBER DIVIDER ───────────────────────────────────────────────── */}
        <div style={{ background: 'hsl(var(--sand))' }}>
          <BerberDivider />
        </div>

        {/* ── ACTIVITIES ───────────────────────────────────────────────────── */}
        <section className="py-20 px-6" style={{ background: 'hsl(var(--surface-dark))' }}>
          <div className="max-w-5xl mx-auto">
            <motion.div
              variants={stagger}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="flex flex-col gap-20"
            >
              {activites.activities.map((act, i) => {
                const isEven = i % 2 === 0;
                return (
                  <motion.article
                    key={act.id}
                    variants={fadeUp}
                    className={`grid grid-cols-1 md:grid-cols-2 gap-0 rounded-2xl overflow-hidden shadow-2xl ${
                      isEven ? '' : 'md:[direction:rtl]'
                    }`}
                  >
                    {/* Image */}
                    <div className="relative h-72 md:h-auto min-h-[320px] overflow-hidden" style={{ direction: 'ltr' }}>
                      <img
                        src={activityImages[act.id] ?? '/airo-assets/images/pages/home/ambiance'}
                        alt={act.name}
                        className="absolute inset-0 w-full h-full object-cover"
                        loading="lazy"
                        width={900}
                        height={600}
                      />
                      {/* Price badge */}
                      <div className="absolute top-4 left-4 bg-primary text-primary-foreground text-sm font-bold px-4 py-1.5 rounded-full shadow-lg">
                        À partir de {act.currency}{act.price} / pers.
                      </div>
                    </div>

                    {/* Content */}
                    <div
                      className="flex flex-col justify-center px-8 py-10"
                      style={{ background: 'hsl(var(--card))', direction: 'ltr' }}
                    >
                      <p className="text-primary text-xs font-semibold tracking-widest uppercase mb-2">{act.tagline}</p>
                      <h2
                        className="text-3xl font-bold text-white mb-4"
                        style={{ fontFamily: 'var(--font-heading)' }}
                      >
                        {act.name}
                      </h2>
                      <p className="text-white/60 text-sm leading-relaxed mb-6">{act.description}</p>

                      {/* Meta chips */}
                      <div className="flex flex-wrap gap-3 mb-6">
                        <span className="flex items-center gap-1.5 text-xs text-white/50 bg-white/5 px-3 py-1.5 rounded-full">
                          <Clock size={12} className="text-primary" />
                          {act.duration}
                        </span>
                        <span className="flex items-center gap-1.5 text-xs text-white/50 bg-white/5 px-3 py-1.5 rounded-full">
                          <Users size={12} className="text-primary" />
                          {act.groupSize}
                        </span>
                        <span className="flex items-center gap-1.5 text-xs text-white/50 bg-white/5 px-3 py-1.5 rounded-full">
                          <Zap size={12} className="text-primary" />
                          {act.difficulty}
                        </span>
                      </div>

                      {/* Highlights */}
                      <ul className="flex flex-col gap-2 mb-6">
                        {act.highlights.map((h: string, j: number) => (
                          <li key={j} className="flex items-start gap-2 text-sm text-white/70">
                            <Star size={13} className="text-primary shrink-0 mt-0.5" />
                            <span>{h}</span>
                          </li>
                        ))}
                      </ul>

                      {/* Best for */}
                      <p className="text-white/35 text-xs mb-6">
                        <span className="text-white/50 font-medium">Idéal pour : </span>
                        {act.bestFor}
                      </p>

                      <Link
                        to="/contact"
                        className="inline-flex items-center gap-2 self-start px-6 py-3 rounded-full bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-all duration-200 hover:scale-105"
                      >
                        Réserver cette excursion
                        <ArrowRight size={15} />
                      </Link>
                    </div>
                  </motion.article>
                );
              })}
            </motion.div>
          </div>
        </section>

        {/* ── NOTE ─────────────────────────────────────────────────────────── */}
        <section className="py-10 px-6" style={{ background: 'hsl(var(--surface-dark))' }}>
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="max-w-3xl mx-auto text-center"
          >
            <p className="text-white/35 text-sm leading-relaxed">{activites.note.text}</p>
          </motion.div>
        </section>

        {/* ── BERBER DIVIDER ───────────────────────────────────────────────── */}
        <div style={{ background: 'hsl(var(--surface-dark))' }}>
          <BerberDivider light />
        </div>

        {/* ── CTA ──────────────────────────────────────────────────────────── */}
        <section className="py-20 px-6" style={{ background: 'hsl(var(--sand))' }}>
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="max-w-2xl mx-auto text-center"
          >
            <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-4">Sur mesure</p>
            <h2
              className="text-3xl md:text-4xl font-bold mb-4"
              style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--surface-dark))' }}
            >
              {activites.cta.heading}
            </h2>
            <p className="mb-8 text-base leading-relaxed" style={{ color: 'hsl(var(--surface-dark) / 0.65)' }}>
              {activites.cta.body}
            </p>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-10 py-4 rounded-full bg-primary text-primary-foreground font-bold text-base hover:bg-primary/90 transition-all duration-200 hover:scale-105"
            >
              {activites.cta.buttonLabel}
              <ArrowRight size={18} />
            </Link>
          </motion.div>
        </section>
      </main>
    </>
  );
}
