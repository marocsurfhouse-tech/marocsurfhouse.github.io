import { Helmet } from '@dr.pogodin/react-helmet';
import { Link } from 'react-router';
import { motion } from 'motion/react';
import { ArrowRight, Check } from 'lucide-react';
import { home } from 'virtual:content';

// ─── Animation variants ───────────────────────────────────────────────────────
const fadeUp = {
  hidden: { opacity: 0, y: 32 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' as const } },
};

const stagger = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.15 } },
};

// ─── Berber geometric divider ─────────────────────────────────────────────────
function BerberDivider({ light = false }: { light?: boolean }) {
  return (
    <div className={`w-full overflow-hidden ${light ? 'text-white/20' : 'text-black/10'}`}>
      <svg viewBox="0 0 400 20" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-5" aria-hidden="true">
        {Array.from({ length: 20 }).map((_, i) => (
          <g key={i} transform={`translate(${i * 20}, 0)`}>
            <polygon points="10,2 18,10 10,18 2,10" stroke="currentColor" strokeWidth="0.8" fill="none" />
            <line x1="10" y1="2" x2="10" y2="18" stroke="currentColor" strokeWidth="0.4" />
            <line x1="2" y1="10" x2="18" y2="10" stroke="currentColor" strokeWidth="0.4" />
          </g>
        ))}
      </svg>
    </div>
  );
}

// ─── Slot URL helper (not user-visible text) ──────────────────────────────────
function packSlot(id: string): string {
  if (id === 'pack-decouverte') return '/airo-assets/images/pages/home/pack-decouverte';
  if (id === 'pack-aventure') return '/airo-assets/images/pages/home/pack-aventure';
  return '/airo-assets/images/pages/home/pack-premium';
}

function activitySlot(id: string): string {
  if (id === 'paradise-valley') return '/airo-assets/images/pages/home/activite-paradise-valley';
  if (id === 'timlaline') return '/airo-assets/images/pages/home/activite-timlaline';
  return '/airo-assets/images/pages/home/activite-imsouan';
}

// ─── Component ────────────────────────────────────────────────────────────────
export default function HomePage() {
  const siteUrl = 'https://marocsurfhouse.com';

  return (
    <>
      <Helmet>
        <title>Maroc Surf House — Surf Camp à Tamraght, Maroc</title>
        <meta
          name="description"
          content="Surf camp à Tamraght, Maroc. Packs surf tout compris (hébergement + cours + activités) et excursions locales : Paradise Valley, Timlaline, Imsouan."
        />
        <link rel="canonical" href={siteUrl} />
        <meta property="og:title" content="Maroc Surf House — Surf Camp à Tamraght" />
        <meta property="og:description" content="Packs surf tout compris et excursions locales à Tamraght, Maroc." />
        <meta property="og:url" content={siteUrl} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content={`${siteUrl}/og-image.svg`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:image" content={`${siteUrl}/og-image.svg`} />
      </Helmet>

      <main>
        {/* ── HERO ─────────────────────────────────────────────────────────── */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          {/* Background image */}
          <img
            src="/airo-assets/images/pages/home/hero"
            alt="Surfeur sur les vagues de l'Atlantique à Tamraght, Maroc"
            className="absolute inset-0 w-full h-full object-cover"
            loading="eager"
            fetchPriority="high"
            width={1920}
            height={1080}
          />
          {/* Warm terracotta overlay */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{ background: 'linear-gradient(to bottom, hsl(var(--surface-dark) / 0.55) 0%, hsl(var(--terracotta) / 0.35) 50%, hsl(var(--surface-dark) / 0.75) 100%)' }}
          />

          {/* Content */}
          <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-primary text-sm font-semibold tracking-widest uppercase mb-4"
            >
              Tamraght · Maroc
            </motion.p>
            <motion.h1
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.35 }}
              className="text-5xl md:text-7xl lg:text-8xl font-bold text-white leading-tight mb-6"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              {home.hero.title}
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="text-white/80 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed"
            >
              {home.hero.subtitle}
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.65 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link
                to="/packs"
                className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-primary text-primary-foreground font-semibold text-base hover:bg-primary/90 transition-all duration-200 hover:scale-105"
              >
                {home.hero.cta}
                <ArrowRight size={18} />
              </Link>
              <Link
                to="/activites"
                className="inline-flex items-center gap-2 px-8 py-4 rounded-full border border-white/40 text-white font-semibold text-base hover:bg-white/10 transition-all duration-200"
              >
                Découvrir les activités
              </Link>
            </motion.div>
          </div>

          {/* Scroll indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2, duration: 0.6 }}
            className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 pointer-events-none"
          >
            <span className="text-white/40 text-xs tracking-widest uppercase">Scroll</span>
            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' as const }}
              className="w-px h-8 bg-gradient-to-b from-white/40 to-transparent"
            />
          </motion.div>
        </section>

        {/* ── PACKS SURF ───────────────────────────────────────────────────── */}
        <section className="py-24 px-6" style={{ background: 'hsl(var(--sand))' }}>
          <div className="max-w-7xl mx-auto">
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-3">Séjours surf</p>
              <h2
                className="text-4xl md:text-5xl font-bold mb-4"
                style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--surface-dark))' }}
              >
                {home.packs.heading}
              </h2>
              <p className="text-lg" style={{ color: 'hsl(var(--surface-dark) / 0.65)' }}>
                {home.packs.subheading}
              </p>
            </motion.div>

            <motion.div
              variants={stagger}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="grid grid-cols-1 md:grid-cols-3 gap-8"
            >
              {home.packs.items.map((pack, i) => (
                <motion.div
                  key={pack.id}
                  variants={fadeUp}
                  whileHover={{ y: -6, transition: { duration: 0.2 } }}
                  className={`rounded-2xl overflow-hidden shadow-xl flex flex-col ${i === 1 ? 'md:-mt-4 md:mb-4' : ''}`}
                  style={{ background: 'hsl(var(--surface-dark))' }}
                >
                  {/* Card image */}
                  <div className="relative h-52 overflow-hidden">
                    <img
                      src={packSlot(pack.id)}
                      alt={pack.name}
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                      loading="lazy"
                      width={800}
                      height={600}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none" />
                    {i === 1 && (
                      <div className="absolute top-4 right-4 bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">
                        Populaire
                      </div>
                    )}
                  </div>

                  {/* Card content */}
                  <div className="p-6 flex flex-col flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <h3
                        className="text-xl font-bold text-white"
                        style={{ fontFamily: 'var(--font-heading)' }}
                      >
                        {pack.name}
                      </h3>
                      <span className="text-xs text-white/50 bg-white/10 px-2 py-1 rounded-full">{pack.duration}</span>
                    </div>
                    <p className="text-white/60 text-sm leading-relaxed mb-5">{pack.description}</p>

                    <ul className="flex flex-col gap-2 mb-6 flex-1">
                      {pack.includes.map((item, j) => (
                        <li key={j} className="flex items-center gap-2 text-sm text-white/70">
                          <Check size={14} className="text-primary shrink-0" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>

                    <div className="flex items-center justify-between mt-auto pt-4 border-t border-white/10">
                      <span className="text-primary font-bold text-lg">{pack.price}</span>
                      <Link
                        to="/packs"
                        className="inline-flex items-center gap-1 text-sm font-semibold text-white hover:text-primary transition-colors"
                      >
                        Réserver <ArrowRight size={14} />
                      </Link>
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* ── BERBER DIVIDER ───────────────────────────────────────────────── */}
        <div style={{ background: 'hsl(var(--sand))' }}>
          <BerberDivider />
        </div>

        {/* ── ACTIVITÉS ────────────────────────────────────────────────────── */}
        <section
          className="py-24 px-6"
          style={{ background: 'hsl(var(--surface-dark))' }}
        >
          <div className="max-w-7xl mx-auto">
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-3">Excursions</p>
              <h2
                className="text-4xl md:text-5xl font-bold text-white mb-4"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {home.activities.heading}
              </h2>
              <p className="text-white/60 text-lg max-w-xl mx-auto">{home.activities.subheading}</p>
            </motion.div>

            <motion.div
              variants={stagger}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="grid grid-cols-1 md:grid-cols-3 gap-6"
            >
              {home.activities.items.map((activity) => (
                <motion.div
                  key={activity.id}
                  variants={fadeUp}
                  whileHover={{ scale: 1.02, transition: { duration: 0.2 } }}
                  className="relative rounded-2xl overflow-hidden h-80 cursor-pointer group"
                >
                  <img
                    src={activitySlot(activity.id)}
                    alt={activity.name}
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    loading="lazy"
                    width={800}
                    height={600}
                  />
                  {/* Warm overlay */}
                  <div
                    className="absolute inset-0 pointer-events-none transition-opacity duration-300 group-hover:opacity-80"
                    style={{ background: 'linear-gradient(to top, hsl(var(--surface-dark) / 0.9) 0%, hsl(var(--terracotta) / 0.2) 60%, transparent 100%)' }}
                  />
                  {/* Text */}
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <p className="text-primary text-xs font-semibold tracking-widest uppercase mb-1">{activity.tagline}</p>
                    <h3
                      className="text-2xl font-bold text-white mb-2"
                      style={{ fontFamily: 'var(--font-heading)' }}
                    >
                      {activity.name}
                    </h3>
                    <p className="text-white/70 text-sm leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-300 max-h-0 group-hover:max-h-20 overflow-hidden">
                      {activity.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </motion.div>

            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="text-center mt-10"
            >
              <Link
                to="/activites"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-primary text-primary font-semibold hover:bg-primary hover:text-primary-foreground transition-all duration-200"
              >
                Voir toutes les activités <ArrowRight size={16} />
              </Link>
            </motion.div>
          </div>
        </section>

        {/* ── BERBER DIVIDER ───────────────────────────────────────────────── */}
        <div style={{ background: 'hsl(var(--surface-dark))' }}>
          <BerberDivider light />
        </div>

        {/* ── POURQUOI NOUS ────────────────────────────────────────────────── */}
        <section className="py-24 px-6 relative overflow-hidden" style={{ background: 'hsl(var(--sand))' }}>
          {/* Background image with overlay */}
          <img
            src="/airo-assets/images/pages/home/ambiance"
            alt="Ambiance surf camp Maroc"
            className="absolute inset-0 w-full h-full object-cover opacity-15"
            loading="lazy"
            width={1200}
            height={800}
          />
          <div className="relative z-10 max-w-6xl mx-auto">
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-3">Notre différence</p>
              <h2
                className="text-4xl md:text-5xl font-bold mb-4"
                style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--surface-dark))' }}
              >
                {home.whyUs.heading}
              </h2>
            </motion.div>

            <motion.div
              variants={stagger}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="grid grid-cols-2 md:grid-cols-4 gap-8"
            >
              {home.whyUs.stats.map((stat) => (
                <motion.div
                  key={stat.id}
                  variants={fadeUp}
                  className="text-center"
                >
                  <div
                    className="text-5xl md:text-6xl font-bold mb-2"
                    style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--primary))' }}
                  >
                    {stat.number}
                  </div>
                  <div
                    className="text-sm font-medium uppercase tracking-wide"
                    style={{ color: 'hsl(var(--surface-dark) / 0.7)' }}
                  >
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </motion.div>

            {/* Key points */}
            <motion.div
              variants={stagger}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16"
            >
              {[
                { title: 'Instructeurs certifiés', body: 'Tous nos moniteurs sont diplômés d\'État et passionnés. Ils adaptent chaque cours à ton niveau pour une progression rapide et sécurisée.' },
                { title: 'Spots exclusifs', body: 'On connaît les meilleurs spots de la région — des plages de Tamraght aux reefs secrets. Chaque session est choisie selon les conditions du jour.' },
                { title: 'Expérience locale', body: 'On ne vend pas juste du surf. On partage notre Maroc : la cuisine, les villages, les gens. Un séjour qui change vraiment.' },
              ].map((point, i) => (
                <motion.div
                  key={i}
                  variants={fadeUp}
                  className="p-6 rounded-2xl"
                  style={{ background: 'hsl(var(--surface-dark) / 0.06)', border: '1px solid hsl(var(--surface-dark) / 0.1)' }}
                >
                  <div
                    className="text-4xl font-bold mb-3"
                    style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--primary) / 0.4)' }}
                  >
                    0{i + 1}
                  </div>
                  <h3
                    className="text-xl font-bold mb-2"
                    style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--surface-dark))' }}
                  >
                    {point.title}
                  </h3>
                  <p className="text-sm leading-relaxed" style={{ color: 'hsl(var(--surface-dark) / 0.65)' }}>
                    {point.body}
                  </p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* ── CTA FINAL ────────────────────────────────────────────────────── */}
        <section
          className="py-28 px-6 relative overflow-hidden"
          style={{ background: 'hsl(var(--surface-dark))' }}
        >
          {/* Decorative wave pattern */}
          <div className="absolute inset-0 opacity-5 pointer-events-none" aria-hidden="true">
            <svg viewBox="0 0 1200 400" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
              <path d="M0 200 Q300 100 600 200 T1200 200" stroke="white" strokeWidth="2" fill="none" />
              <path d="M0 240 Q300 140 600 240 T1200 240" stroke="white" strokeWidth="1.5" fill="none" />
              <path d="M0 280 Q300 180 600 280 T1200 280" stroke="white" strokeWidth="1" fill="none" />
            </svg>
          </div>

          <div className="relative z-10 max-w-3xl mx-auto text-center">
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-4">Rejoins-nous</p>
              <h2
                className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {home.cta.heading}
              </h2>
              <p className="text-white/60 text-lg mb-10 leading-relaxed">{home.cta.body}</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  to="/contact"
                  className="inline-flex items-center gap-2 px-10 py-4 rounded-full bg-primary text-primary-foreground font-bold text-base hover:bg-primary/90 transition-all duration-200 hover:scale-105"
                >
                  {home.cta.buttonLabel}
                  <ArrowRight size={18} />
                </Link>
                <Link
                  to="/packs"
                  className="inline-flex items-center gap-2 px-10 py-4 rounded-full border border-white/30 text-white font-semibold hover:bg-white/10 transition-all duration-200"
                >
                  Voir les packs
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
    </>
  );
}
