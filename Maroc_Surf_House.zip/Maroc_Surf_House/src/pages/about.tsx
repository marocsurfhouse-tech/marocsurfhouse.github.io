import { Helmet } from '@dr.pogodin/react-helmet';
import { Link } from 'react-router';
import { motion } from 'motion/react';
import { ArrowRight, Waves, Heart, Globe, Sun, MapPin, Plane, Calendar } from 'lucide-react';
import { about } from 'virtual:content';
import { ContentListContext } from '@airo/content';

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.55, ease: 'easeOut' as const } },
};
const stagger = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.1 } },
};

function BerberDivider({ light = false }: { light?: boolean }) {
  return (
    <div className={`w-full overflow-hidden ${light ? 'text-white/15' : 'text-black/10'}`}>
      <svg viewBox="0 0 400 20" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-5" aria-hidden="true">
        {Array.from({ length: 20 }).map((_, idx) => (
          <g key={idx} transform={`translate(${idx * 20}, 0)`}>
            <polygon points="10,2 18,10 10,18 2,10" stroke="currentColor" strokeWidth="0.8" fill="none" />
            <line x1="10" y1="2" x2="10" y2="18" stroke="currentColor" strokeWidth="0.4" />
            <line x1="2" y1="10" x2="18" y2="10" stroke="currentColor" strokeWidth="0.4" />
          </g>
        ))}
      </svg>
    </div>
  );
}

const siteUrl = 'https://marocsurfhouse.com';
const pageUrl = `${siteUrl}/a-propos`;

export default function AboutPage() {
  return (
    <>
      <Helmet>
        <title>À propos — Maroc Surf House, surf camp à Tamraght</title>
        <meta
          name="description"
          content="Découvrez l'histoire de Maroc Surf House, notre équipe passionnée et le village de Tamraght. Un surf camp authentique au cœur du Maroc depuis 2015."
        />
        <link rel="canonical" href={pageUrl} />
        <meta property="og:title" content="À propos — Maroc Surf House" />
        <meta property="og:description" content="L'histoire, l'équipe et les valeurs de Maroc Surf House, surf camp à Tamraght, Maroc." />
        <meta property="og:url" content={pageUrl} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content={`${siteUrl}/og-image.svg`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:image" content={`${siteUrl}/og-image.svg`} />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@graph': [
            {
              '@type': 'AboutPage',
              '@id': `${pageUrl}#webpage`,
              name: 'À propos — Maroc Surf House',
              url: pageUrl,
              isPartOf: { '@id': `${siteUrl}/#website` },
              about: { '@id': `${siteUrl}/#organization` },
            },
            {
              '@type': 'BreadcrumbList',
              '@id': `${pageUrl}#breadcrumb`,
              itemListElement: [
                { '@type': 'ListItem', position: 1, name: 'Accueil', item: siteUrl },
                { '@type': 'ListItem', position: 2, name: 'À propos', item: pageUrl },
              ],
            },
            {
              '@type': 'Organization',
              '@id': `${siteUrl}/#organization`,
              name: 'Maroc Surf House',
              url: siteUrl,
              logo: `${siteUrl}/airo-assets/images/logo/horizontal`,
              address: {
                '@type': 'PostalAddress',
                addressLocality: 'Tamraght',
                addressRegion: 'Agadir-Ida-Ou-Tanane',
                addressCountry: 'MA',
              },
              telephone: '+212606461292',
              sameAs: ['https://instagram.com/marocsurfhouse', 'https://facebook.com/marocsurfhouse'],
            },
          ],
        }).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main>
        {/* ── HERO ─────────────────────────────────────────────────────────── */}
        <section className="relative h-[70vh] min-h-[460px] flex items-end overflow-hidden">
          <img
            src="/airo-assets/images/pages/about/hero"
            alt="Maroc Surf House — terrasse avec vue sur l'Atlantique à Tamraght"
            className="absolute inset-0 w-full h-full object-cover"
            loading="eager"
            fetchPriority="high"
            width={1920}
            height={700}
          />
          <div
            className="absolute inset-0 pointer-events-none"
            style={{ background: 'linear-gradient(to bottom, hsl(var(--surface-dark) / 0.25) 0%, hsl(var(--surface-dark) / 0.8) 65%, hsl(var(--surface-dark)) 100%)' }}
          />
          <div className="relative z-10 w-full px-6 pb-16 max-w-5xl mx-auto">
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-primary text-sm font-semibold tracking-widest uppercase mb-3"
            >
              {about.hero.eyebrow}
            </motion.p>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.35 }}
              className="text-5xl md:text-7xl font-bold text-white mb-4 max-w-3xl"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              {about.hero.title}
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="text-white/65 text-xl max-w-2xl leading-relaxed"
            >
              {about.hero.subtitle}
            </motion.p>
          </div>
        </section>

        {/* ── HISTOIRE ─────────────────────────────────────────────────────── */}
        <section className="py-24 px-6" style={{ background: 'hsl(var(--surface-dark))' }}>
          <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Texte */}
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-4">{about.story.eyebrow}</p>
              <h2
                className="text-3xl md:text-4xl font-bold text-white mb-8"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {about.story.title}
              </h2>
              <ContentListContext field="about.story.paragraphs">
                <div className="flex flex-col gap-5">
                  {about.story.paragraphs.map((p) => (
                    <p key={p.id} className="text-white/65 leading-relaxed">
                      {p.text}
                    </p>
                  ))}
                </div>
              </ContentListContext>
            </motion.div>

            {/* Image décorative — ambiance camp */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, ease: 'easeOut' as const }}
              className="relative"
            >
              <div className="rounded-2xl overflow-hidden aspect-[4/5]">
                <img
                  src="/airo-assets/images/pages/home/ambiance"
                  alt="Ambiance Maroc Surf House — groupe de surfeurs au coucher du soleil"
                  className="w-full h-full object-cover"
                  loading="lazy"
                  width={600}
                  height={750}
                />
              </div>
              {/* Badge flottant */}
              <div
                className="absolute -bottom-5 -left-5 rounded-xl px-5 py-4 shadow-xl"
                style={{ background: 'hsl(var(--primary))' }}
              >
                <p className="text-primary-foreground font-bold text-2xl" style={{ fontFamily: 'var(--font-heading)' }}>2015</p>
                <p className="text-primary-foreground/80 text-xs">Fondé à Tamraght</p>
              </div>
            </motion.div>
          </div>
        </section>

        <div style={{ background: 'hsl(var(--surface-dark))' }}>
          <BerberDivider light />
        </div>

        {/* ── VALEURS ──────────────────────────────────────────────────────── */}
        <section className="py-24 px-6" style={{ background: 'hsl(var(--sand))' }}>
          <div className="max-w-5xl mx-auto">
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="text-center mb-14"
            >
              <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-3">{about.values.eyebrow}</p>
              <h2
                className="text-3xl md:text-4xl font-bold"
                style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--surface-dark))' }}
              >
                {about.values.title}
              </h2>
            </motion.div>

            <ContentListContext field="about.values.items">
              <motion.div
                variants={stagger}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
              >
                {about.values.items.map((v) => (
                  <motion.div
                    key={v.id}
                    variants={fadeUp}
                    className="rounded-2xl p-7 flex flex-col gap-4"
                    style={{ background: 'hsl(var(--surface-dark))' }}
                  >
                    <div
                      className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
                      style={{ background: 'hsl(var(--primary) / 0.15)' }}
                    >
                      {v.icon === 'wave'  && <Waves size={22} className="text-primary" />}
                      {v.icon === 'heart' && <Heart size={22} className="text-primary" />}
                      {v.icon === 'earth' && <Globe size={22} className="text-primary" />}
                      {v.icon === 'sun'   && <Sun   size={22} className="text-primary" />}
                    </div>
                    <h3
                      className="text-white font-bold text-lg"
                      style={{ fontFamily: 'var(--font-heading)' }}
                    >
                      {v.title}
                    </h3>
                    <p className="text-white/55 text-sm leading-relaxed">{v.description}</p>
                  </motion.div>
                ))}
              </motion.div>
            </ContentListContext>
          </div>
        </section>

        <div style={{ background: 'hsl(var(--sand))' }}>
          <BerberDivider />
        </div>

        {/* ── ÉQUIPE ───────────────────────────────────────────────────────── */}
        <section className="py-24 px-6" style={{ background: 'hsl(var(--surface-dark))' }}>
          <div className="max-w-5xl mx-auto">
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="text-center mb-14"
            >
              <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-3">{about.team.eyebrow}</p>
              <h2
                className="text-3xl md:text-4xl font-bold text-white"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {about.team.title}
              </h2>
            </motion.div>

            <ContentListContext field="about.team.members">
              <motion.div
                variants={stagger}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                className="grid grid-cols-1 md:grid-cols-3 gap-8"
              >
                {about.team.members.map((member) => (
                  <motion.div key={member.id} variants={fadeUp} className="flex flex-col items-center text-center">
                    <div className="w-32 h-32 rounded-full overflow-hidden mb-5 ring-2 ring-primary/30">
                      <img
                        src={member.image}
                        alt={member.name}
                        className="w-full h-full object-cover"
                        loading="lazy"
                        width={128}
                        height={128}
                      />
                    </div>
                    <h3
                      className="text-white font-bold text-xl mb-1"
                      style={{ fontFamily: 'var(--font-heading)' }}
                    >
                      {member.name}
                    </h3>
                    <p className="text-primary text-xs font-semibold uppercase tracking-widest mb-4">{member.role}</p>
                    <p className="text-white/55 text-sm leading-relaxed">{member.bio}</p>
                  </motion.div>
                ))}
              </motion.div>
            </ContentListContext>
          </div>
        </section>

        <div style={{ background: 'hsl(var(--surface-dark))' }}>
          <BerberDivider light />
        </div>

        {/* ── LOCALISATION ─────────────────────────────────────────────────── */}
        <section className="py-24 px-6" style={{ background: 'hsl(var(--sand))' }}>
          <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-4">{about.location.eyebrow}</p>
              <h2
                className="text-3xl md:text-4xl font-bold mb-6"
                style={{ fontFamily: 'var(--font-heading)', color: 'hsl(var(--surface-dark))' }}
              >
                {about.location.title}
              </h2>
              <p className="text-foreground/65 leading-relaxed mb-8">{about.location.description}</p>
              <ContentListContext field="about.location.details">
                <ul className="flex flex-col gap-4">
                  {about.location.details.map((d) => (
                    <li key={d.id} className="flex items-start gap-3">
                      {d.label === 'Adresse'  && <MapPin   size={16} className="text-primary shrink-0 mt-0.5" />}
                      {d.label === 'Aéroport' && <Plane    size={16} className="text-primary shrink-0 mt-0.5" />}
                      {d.label !== 'Adresse' && d.label !== 'Aéroport' && <Calendar size={16} className="text-primary shrink-0 mt-0.5" />}
                      <div>
                        <span className="text-foreground/40 text-xs font-semibold uppercase tracking-widest block mb-0.5">{d.label}</span>
                        <span className="text-foreground/80 text-sm">{d.value}</span>
                      </div>
                    </li>
                  ))}
                </ul>
              </ContentListContext>
            </motion.div>

            {/* Carte Google Maps embed */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, ease: 'easeOut' as const }}
              className="rounded-2xl overflow-hidden shadow-xl aspect-[4/3]"
            >
              <iframe
                title="Localisation Maroc Surf House — Tamraght, Maroc"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3456.789!2d-9.7197!3d30.4897!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xdb3b6e9e9e9e9e9%3A0x0!2sTamraght%2C+Maroc!5e0!3m2!1sfr!2sfr!4v1234567890"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </motion.div>
          </div>
        </section>

        {/* ── CTA FINAL ────────────────────────────────────────────────────── */}
        <section className="py-20 px-6" style={{ background: 'hsl(var(--surface-dark))' }}>
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="max-w-2xl mx-auto text-center"
          >
            <h2
              className="text-3xl md:text-4xl font-bold text-white mb-4"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              {about.cta.title}
            </h2>
            <p className="text-white/55 mb-10 text-lg">{about.cta.subtitle}</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/packs"
                className="inline-flex items-center justify-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-full font-bold text-sm hover:bg-primary/90 transition-all hover:scale-[1.02] shadow-lg shadow-primary/20"
              >
                {about.cta.buttonPacks}
                <ArrowRight size={16} />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center justify-center gap-2 border border-white/20 text-white px-8 py-4 rounded-full font-semibold text-sm hover:bg-white/10 transition-all"
              >
                {about.cta.buttonContact}
              </Link>
            </div>
          </motion.div>
        </section>
      </main>
    </>
  );
}
