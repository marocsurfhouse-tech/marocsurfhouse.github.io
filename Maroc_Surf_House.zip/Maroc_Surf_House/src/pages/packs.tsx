import { Helmet } from '@dr.pogodin/react-helmet';
import { useState } from 'react';
import { Link } from 'react-router';
import { motion } from 'motion/react';
import {
  ArrowRight,
  Check,
  X,
  Clock,
  Moon,
  UtensilsCrossed,
  BedDouble,
  BarChart2,
  CalendarDays,
  Waves,
  Home,
  Mountain,
  Star,
  Sparkles,
  CreditCard,
  Copy,
  CheckCheck,
  Building2,
} from 'lucide-react';
import { packs } from 'virtual:content';
import { ContentListContext } from '@airo/content';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.55, ease: 'easeOut' as const } },
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.12 } } };

const siteUrl = 'https://marocsurfhouse.com';
const pageUrl = `${siteUrl}/packs`;

interface PackInfo {
  name: string;
  price: number;
  slug: string;
}

function BankTransferModal({ pack, onClose }: { pack: PackInfo; onClose: () => void }) {
  const [copied, setCopied] = useState<string | null>(null);
  const acompte = Math.round(pack.price * 0.15);

  const bankDetails = [
    { label: 'Bénéficiaire', value: 'Maroc Surf House SARL' },
    { label: 'IBAN', value: 'MA64 0110 0000 0000 1234 5678 900' },
    { label: 'BIC / SWIFT', value: 'BMCEMAMC' },
    { label: 'Banque', value: 'Banque Marocaine du Commerce Extérieur' },
    { label: 'Référence', value: 'MSH-' + pack.slug.toUpperCase() + '-' + Date.now().toString().slice(-6) },
  ];

  const copyToClipboard = (value: string, key: string) => {
    navigator.clipboard.writeText(value);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.75)' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.25, ease: 'easeOut' as const }}
        className="relative w-full max-w-lg rounded-2xl overflow-hidden shadow-2xl"
        style={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border) / 0.2)' }}
      >
        <div className="flex items-center justify-between px-6 py-5" style={{ background: 'hsl(var(--primary))', color: 'hsl(var(--primary-foreground))' }}>
          <div className="flex items-center gap-3">
            <Building2 size={22} />
            <div>
              <p className="font-bold text-base" style={{ fontFamily: 'var(--font-heading)' }}>Réservation par virement</p>
              <p className="text-sm opacity-80">{pack.name}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-full hover:bg-white/20 transition-colors" aria-label="Fermer">
            <X size={18} />
          </button>
        </div>

        <div className="px-6 py-5 space-y-5">
          <div className="rounded-xl p-4 flex items-start gap-4" style={{ background: 'hsl(var(--primary) / 0.08)', border: '1px solid hsl(var(--primary) / 0.2)' }}>
            <CreditCard size={20} className="mt-0.5 shrink-0" style={{ color: 'hsl(var(--primary))' }} />
            <div>
              <p className="font-semibold text-sm" style={{ color: 'hsl(var(--foreground))' }}>
                Acompte de réservation :{' '}
                <span style={{ color: 'hsl(var(--primary))' }}>{acompte} €</span>
                <span className="font-normal text-xs ml-1" style={{ color: 'hsl(var(--muted-foreground))' }}>
                  (15% du total : {pack.price} €)
                </span>
              </p>
              <p className="text-xs mt-1" style={{ color: 'hsl(var(--muted-foreground))' }}>
                Le solde ({pack.price - acompte} €) est réglé à votre arrivée. Annulation gratuite jusqu'à 8 jours avant.
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase tracking-wide" style={{ color: 'hsl(var(--muted-foreground))' }}>Coordonnées bancaires</p>
            <div className="rounded-xl overflow-hidden" style={{ border: '1px solid hsl(var(--border) / 0.25)' }}>
              {bankDetails.map((item, i) => (
                <div
                  key={item.label}
                  className="flex items-center justify-between px-4 py-3 gap-3"
                  style={{
                    background: i % 2 === 0 ? 'hsl(var(--muted) / 0.3)' : 'transparent',
                    borderBottom: i < bankDetails.length - 1 ? '1px solid hsl(var(--border) / 0.15)' : 'none',
                  }}
                >
                  <div className="min-w-0">
                    <p className="text-xs" style={{ color: 'hsl(var(--muted-foreground))' }}>{item.label}</p>
                    <p className="text-sm font-mono font-medium truncate" style={{ color: 'hsl(var(--foreground))' }}>{item.value}</p>
                  </div>
                  <button
                    onClick={() => copyToClipboard(item.value, item.label)}
                    className="shrink-0 p-1.5 rounded-lg transition-colors"
                    style={{ color: copied === item.label ? 'hsl(var(--primary))' : 'hsl(var(--muted-foreground))' }}
                    aria-label={'Copier ' + item.label}
                  >
                    {copied === item.label ? <CheckCheck size={15} /> : <Copy size={15} />}
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase tracking-wide" style={{ color: 'hsl(var(--muted-foreground))' }}>Étapes de réservation</p>
            <ol className="space-y-2">
              {[
                "Effectuez le virement de l'acompte avec la référence indiquée",
                'Envoyez la confirmation de virement à contact@marocsurfhouse.com',
                'Recevez votre confirmation de réservation sous 24h',
              ].map((step, i) => (
                <li key={i} className="flex items-start gap-3 text-sm" style={{ color: 'hsl(var(--foreground) / 0.8)' }}>
                  <span
                    className="shrink-0 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold mt-0.5"
                    style={{ background: 'hsl(var(--primary))', color: 'hsl(var(--primary-foreground))' }}
                  >
                    {i + 1}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
          </div>

          <div className="flex gap-3 pt-1">
            <Link
              to="/contact"
              onClick={onClose}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-full font-bold text-sm transition-all hover:scale-[1.02]"
              style={{ background: 'hsl(var(--primary))', color: 'hsl(var(--primary-foreground))' }}
            >
              Confirmer par email
              <ArrowRight size={14} />
            </Link>
            <button
              onClick={onClose}
              className="px-5 py-3 rounded-full font-semibold text-sm border transition-all hover:bg-white/5"
              style={{ borderColor: 'hsl(var(--border) / 0.3)', color: 'hsl(var(--muted-foreground))' }}
            >
              Fermer
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default function PacksPage() {
  const [selectedPack, setSelectedPack] = useState<PackInfo | null>(null);
  return (
    <>
      <Helmet>
        <title>Packs Surf Tout Inclus — Maroc Surf House, Tamraght</title>
        <meta
          name="description"
          content="Découvrez nos packs surf tout inclus à Tamraght, Maroc. Cours, hébergement, repas et transferts. Packs Découverte 3j, Aventure 5j et Premium 7j dès 290€."
        />
        <link rel="canonical" href={pageUrl} />
        <meta property="og:title" content="Packs Surf Tout Inclus — Maroc Surf House" />
        <meta property="og:description" content="Packs surf tout inclus à Tamraght dès 290€. Cours, hébergement, repas et transferts inclus." />
        <meta property="og:url" content={pageUrl} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content={`${siteUrl}/og-image.svg`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:image" content={`${siteUrl}/og-image.svg`} />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@graph': [
            {
              '@type': 'CollectionPage',
              '@id': `${pageUrl}#webpage`,
              name: 'Packs Surf Tout Inclus — Maroc Surf House',
              url: pageUrl,
              description: 'Packs surf tout inclus à Tamraght dès 290€. Cours, hébergement, repas et transferts inclus.',
              isPartOf: { '@id': `${siteUrl}/#website` },
            },
            {
              '@type': 'BreadcrumbList',
              '@id': `${pageUrl}#breadcrumb`,
              itemListElement: [
                { '@type': 'ListItem', position: 1, name: 'Accueil', item: siteUrl },
                { '@type': 'ListItem', position: 2, name: 'Packs Surf', item: pageUrl },
              ],
            },
          ],
        }).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main>
        {/* ── HERO ─────────────────────────────────────────────────────────── */}
        <section className="relative h-[55vh] min-h-[380px] flex items-end overflow-hidden">
          <img
            src="/airo-assets/images/pages/packs/hero"
            alt="Vagues de l'Atlantique sur la côte de Tamraght, Maroc"
            className="absolute inset-0 w-full h-full object-cover"
            loading="eager"
            fetchPriority="high"
            width={1920}
            height={700}
          />
          <div
            className="absolute inset-0 pointer-events-none"
            style={{ background: 'linear-gradient(to bottom, hsl(var(--surface-dark) / 0.2) 0%, hsl(var(--surface-dark) / 0.85) 70%, hsl(var(--surface-dark)) 100%)' }}
          />
          <div className="relative z-10 w-full px-6 pb-14 max-w-5xl mx-auto">
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, delay: 0.2 }}
              className="text-primary text-sm font-semibold tracking-widest uppercase mb-3"
            >
              {packs.hero.eyebrow}
            </motion.p>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.35 }}
              className="text-5xl md:text-6xl font-bold text-white mb-4"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              {packs.hero.title}
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="text-white/60 text-lg max-w-xl"
            >
              {packs.hero.subtitle}
            </motion.p>
          </div>
        </section>

        {/* ── PACKS ────────────────────────────────────────────────────────── */}
        <section className="py-20 px-6" style={{ background: 'hsl(var(--surface-dark))' }}>
          <div className="max-w-5xl mx-auto">
            <ContentListContext field="packs.packs">
              <motion.div
                variants={stagger}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                className="flex flex-col gap-8"
              >
                {packs.packs.map((pack) => (
                  <motion.article
                    key={pack.id}
                    variants={fadeUp}
                    className="relative rounded-2xl overflow-hidden border"
                    style={{
                      borderColor: pack.popular ? 'hsl(var(--primary) / 0.5)' : 'hsl(var(--border) / 0.15)',
                      background: 'hsl(var(--card))',
                    }}
                  >
                    {/* Badge populaire */}
                    {pack.popular && (
                      <div
                        className="absolute top-0 left-0 right-0 text-center py-2 text-xs font-bold tracking-widest uppercase"
                        style={{ background: 'hsl(var(--primary))', color: 'hsl(var(--primary-foreground))' }}
                      >
                        {pack.badge}
                      </div>
                    )}

                    <div className={`grid grid-cols-1 lg:grid-cols-3 ${pack.popular ? 'pt-9' : ''}`}>
                      {/* Image */}
                      <div className="relative lg:col-span-1 aspect-[4/3] lg:aspect-auto min-h-[220px]">
                        <img
                          src={`/airo-assets/images/pages/home/pack-${pack.slug}`}
                          alt={pack.name}
                          className="absolute inset-0 w-full h-full object-cover"
                          loading="lazy"
                          width={480}
                          height={360}
                        />
                        <div className="absolute inset-0 pointer-events-none" style={{ background: 'linear-gradient(to right, transparent 60%, hsl(var(--card)))' }} />
                        {/* Prix sur l'image */}
                        <div className="absolute bottom-4 left-4 lg:hidden">
                          <div className="flex items-baseline gap-2">
                            <span className="text-white/50 line-through text-sm">{pack.priceOriginal}{pack.currency}</span>
                            <span className="text-white font-bold text-3xl" style={{ fontFamily: 'var(--font-heading)' }}>{pack.price}{pack.currency}</span>
                          </div>
                          <span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={{ background: 'hsl(var(--primary))', color: 'hsl(var(--primary-foreground))' }}>{pack.discount}</span>
                        </div>
                      </div>

                      {/* Contenu */}
                      <div className="lg:col-span-2 p-7 flex flex-col gap-5">
                        {/* Header */}
                        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                          <div>
                            <h2 className="text-2xl font-bold text-white mb-1" style={{ fontFamily: 'var(--font-heading)' }}>
                              {pack.name}
                            </h2>
                            <p className="text-white/50 text-sm">{pack.tagline}</p>
                          </div>
                          {/* Prix desktop */}
                          <div className="hidden sm:flex flex-col items-end shrink-0">
                            <span className="text-white/40 line-through text-sm">{pack.priceOriginal}{pack.currency}</span>
                            <span className="text-white font-bold text-3xl" style={{ fontFamily: 'var(--font-heading)' }}>{pack.price}{pack.currency}</span>
                            <span className="text-xs font-semibold px-2 py-0.5 rounded-full mt-1" style={{ background: 'hsl(var(--primary))', color: 'hsl(var(--primary-foreground))' }}>{pack.discount}</span>
                          </div>
                        </div>

                        {/* Badges infos */}
                        <div className="flex flex-wrap gap-2">
                          <span className="flex items-center gap-1.5 text-xs text-white/60 bg-white/5 px-3 py-1.5 rounded-full">
                            <Clock size={12} className="text-primary" />
                            {pack.duration}
                          </span>
                          <span className="flex items-center gap-1.5 text-xs text-white/60 bg-white/5 px-3 py-1.5 rounded-full">
                            <Moon size={12} className="text-primary" />
                            {pack.nights}
                          </span>
                          <span className="flex items-center gap-1.5 text-xs text-white/60 bg-white/5 px-3 py-1.5 rounded-full">
                            <UtensilsCrossed size={12} className="text-primary" />
                            {pack.meals}
                          </span>
                          <span className="flex items-center gap-1.5 text-xs text-white/60 bg-white/5 px-3 py-1.5 rounded-full">
                            <BedDouble size={12} className="text-primary" />
                            {pack.accommodation}
                          </span>
                          <span className="flex items-center gap-1.5 text-xs text-white/60 bg-white/5 px-3 py-1.5 rounded-full">
                            <BarChart2 size={12} className="text-primary" />
                            {pack.level}
                          </span>
                          <span className="flex items-center gap-1.5 text-xs text-white/60 bg-white/5 px-3 py-1.5 rounded-full">
                            <CalendarDays size={12} className="text-primary" />
                            {pack.season}
                          </span>
                        </div>

                        {/* Highlights */}
                        <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {pack.highlights.map((h) => (
                            <li key={h.id} className="flex items-center gap-2 text-sm text-white/70">
                              {h.icon === 'waves'    && <Waves size={18} className="text-primary shrink-0" />}
                              {h.icon === 'home'     && <Home size={18} className="text-primary shrink-0" />}
                              {h.icon === 'utensils' && <UtensilsCrossed size={18} className="text-primary shrink-0" />}
                              {h.icon === 'mountain' && <Mountain size={18} className="text-primary shrink-0" />}
                              {h.icon === 'star'     && <Star size={18} className="text-primary shrink-0" />}
                              {h.icon === 'sparkles' && <Sparkles size={18} className="text-primary shrink-0" />}
                              {!['waves','home','utensils','mountain','star','sparkles'].includes(h.icon) && <Check size={18} className="text-primary shrink-0" />}
                              <span>{h.label}</span>
                            </li>
                          ))}
                        </ul>

                        {/* CTA */}
                        <div className="flex flex-col sm:flex-row gap-3 pt-1">
                          <Link
                            to={`/packs/${pack.slug}`}
                            className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-full font-bold text-sm transition-all duration-200 hover:scale-[1.02]"
                            style={{ background: 'hsl(var(--primary))', color: 'hsl(var(--primary-foreground))' }}
                          >
                            Voir le programme
                            <ArrowRight size={15} />
                          </Link>
                          <button
                            onClick={() => setSelectedPack({ name: pack.name, price: Number(pack.price), slug: pack.slug })}
                            className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-full font-semibold text-sm border transition-all hover:bg-white/5"
                            style={{ borderColor: 'hsl(var(--border) / 0.3)', color: 'hsl(var(--foreground) / 0.7)' }}
                          >
                            Réserver
                          </button>
                        </div>

                        {/* Annulation */}
                        <p className="text-white/30 text-xs flex items-center gap-1.5">
                          <Check size={11} className="text-primary" />
                          Annulation gratuite jusqu'à 8 jours avant l'arrivée · Confirmation instantanée · Acompte 15%
                        </p>
                      </div>
                    </div>
                  </motion.article>
                ))}
              </motion.div>
            </ContentListContext>
          </div>
        </section>

        {/* ── INCLUS / EXCLUS ──────────────────────────────────────────────── */}
        <section className="py-20 px-6" style={{ background: 'hsl(var(--card))' }}>
          <div className="max-w-5xl mx-auto">
            <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-12">
              <h2 className="text-3xl font-bold text-white" style={{ fontFamily: 'var(--font-heading)' }}>
                Ce qui est inclus dans tous nos packs
              </h2>
            </motion.div>
            <motion.div
              variants={stagger}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="grid grid-cols-1 md:grid-cols-2 gap-6"
            >
              {/* Inclus */}
              <motion.div variants={fadeUp} className="rounded-2xl p-7" style={{ background: 'hsl(var(--surface-dark))' }}>
                <h3 className="text-white font-bold text-lg mb-5 flex items-center gap-2" style={{ fontFamily: 'var(--font-heading)' }}>
                  <Check size={18} className="text-primary" />
                  Toujours inclus
                </h3>
                <ul className="flex flex-col gap-3">
                  {['Cours de surf avec moniteur certifié', 'Matériel de surf (planche + combinaison)', 'Transport vers les spots de surf', 'Transfert aéroport Agadir aller-retour', 'Hébergement selon le pack', 'Repas selon le pack'].map((item, i) => (
                    <li key={i} className="flex items-start gap-2.5 text-sm text-white/65">
                      <Check size={14} className="text-primary shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
              {/* Exclus */}
              <motion.div variants={fadeUp} className="rounded-2xl p-7" style={{ background: 'hsl(var(--surface-dark))' }}>
                <h3 className="text-white font-bold text-lg mb-5 flex items-center gap-2" style={{ fontFamily: 'var(--font-heading)' }}>
                  <X size={18} className="text-muted-foreground" />
                  Non inclus
                </h3>
                <ul className="flex flex-col gap-3">
                  {['Vols internationaux', 'Assurance voyage (recommandée)', 'Dépenses personnelles', 'Boissons en dehors des repas inclus', 'Activités optionnelles supplémentaires'].map((item, i) => (
                    <li key={i} className="flex items-start gap-2.5 text-sm text-white/65">
                      <X size={14} className="text-muted-foreground shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* ── FAQ ──────────────────────────────────────────────────────────── */}
        <section className="py-20 px-6" style={{ background: 'hsl(var(--surface-dark))' }}>
          <div className="max-w-3xl mx-auto">
            <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-12">
              <p className="text-primary text-sm font-semibold tracking-widest uppercase mb-3">Questions fréquentes</p>
              <h2 className="text-3xl font-bold text-white" style={{ fontFamily: 'var(--font-heading)' }}>
                Tout ce que tu veux savoir
              </h2>
            </motion.div>
            <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
              <ContentListContext field="packs.faq">
                <Accordion type="single" collapsible className="flex flex-col gap-3">
                  {packs.faq.map((item, idx) => (
                    <AccordionItem
                      key={item.id}
                      value={String(idx)}
                      className="rounded-xl border px-6"
                      style={{ borderColor: 'hsl(var(--border) / 0.15)', background: 'hsl(var(--card))' }}
                    >
                      <AccordionTrigger className="text-white font-semibold text-sm py-5 hover:no-underline">
                        {item.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-white/55 text-sm pb-5 leading-relaxed">
                        {item.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </ContentListContext>
            </motion.div>
          </div>
        </section>

        {/* ── CTA FINAL ────────────────────────────────────────────────────── */}
        <section className="py-20 px-6" style={{ background: 'hsl(var(--card))' }}>
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="max-w-2xl mx-auto text-center"
          >
            <h2 className="text-3xl font-bold text-white mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
              {packs.cta.heading}
            </h2>
            <p className="text-white/50 mb-10 text-lg">{packs.cta.sub}</p>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-10 py-4 rounded-full font-bold text-sm hover:scale-105 transition-all duration-200 shadow-lg"
              style={{ background: 'hsl(var(--primary))', color: 'hsl(var(--primary-foreground))', boxShadow: '0 8px 30px hsl(var(--primary) / 0.3)' }}
            >
              {packs.cta.button}
              <ArrowRight size={16} />
            </Link>
          </motion.div>
        </section>
      </main>

      {selectedPack && (
        <BankTransferModal pack={selectedPack} onClose={() => setSelectedPack(null)} />
      )}
    </>
  );
}
