import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { useState, type FormEvent } from 'react';
import { MapPin, Mail, Phone, Clock, Instagram, Facebook, Youtube, CheckCircle } from 'lucide-react';
import { contact } from 'virtual:content';

// ─── Animation variants ───────────────────────────────────────────────────────
const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' as const } },
};
const stagger = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.1 } },
};

// ─── Berber divider ───────────────────────────────────────────────────────────
function BerberDivider({ light = false }: { light?: boolean }) {
  return (
    <div className={`w-full overflow-hidden ${light ? 'text-white/15' : 'text-black/10'}`}>
      <svg viewBox="0 0 400 20" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-5" aria-hidden="true">
        {Array.from({ length: 20 }).map((_, idx) => (
          <g key={idx} transform={`translate(${idx * 20}, 0)`}>
            <polygon points="10,2 18,10 10,18 2,10" stroke="currentColor" strokeWidth="0.8" fill="none" />
            <line x1="10" y1="2" x2="10" y2="18" stroke="currentColor" strokeWidth="0.4" />
            <line x1="2" y1="10" x2="18" y2="10" stroke="currentColor" strokeWidth="0.4" />
          </g>
        ))}
      </svg>
    </div>
  );
}

type FormStatus = 'idle' | 'sending' | 'success' | 'error';

// ─── Page ─────────────────────────────────────────────────────────────────────
export default function ContactPage() {
  const siteUrl = 'https://marocsurfhouse.com';
  const pageUrl = `${siteUrl}/contact`;

  const [status, setStatus] = useState<FormStatus>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  // Defined inside the component — never picked up by the content layer
  const selectPacks = [
    'Pack Découverte (3 jours)',
    'Pack Aventure (7 jours)',
    'Pack Premium (10 jours)',
    'Excursion Paradise Valley',
    'Excursion Timlaline',
    'Excursion Imsouan',
    'Autre / Renseignement général',
  ];

  const selectLevels = [
    'Débutant — jamais surfé',
    'Débutant — quelques sessions',
    'Intermédiaire — je me débrouille',
    'Avancé — je surfe régulièrement',
  ];

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);

    // Honeypot check — bail silently if filled by a bot
    if (formData.get('_gotcha')) return;

    const name      = String(formData.get('name')      ?? '').trim();
    const email     = String(formData.get('email')     ?? '').trim();
    const phone     = String(formData.get('phone')     ?? '').trim();
    const pack      = String(formData.get('pack')      ?? '').trim();
    const level     = String(formData.get('level')     ?? '').trim();
    const arrival   = String(formData.get('arrival')   ?? '').trim();
    const departure = String(formData.get('departure') ?? '').trim();
    const message   = String(formData.get('message')   ?? '').trim();

    setStatus('sending');
    setErrorMsg('');

    try {
      // Field mapping: only the message textarea goes in messages_attributes[0].body.
      // All other fields (dropdowns, dates, phone) go in conversation.data as { "Label": value } pairs.
      const res = await fetch('/api/contact/contact-us', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversation: {
            messages_attributes: [{ body: message || 'Nouvelle demande de contact' }],
            data: {
              __gd_contact_form_title: 'Contact Maroc Surf House',
              'Pack ou activité': pack,
              'Niveau de surf': level,
              "Date d'arrivée": arrival,
              'Date de départ': departure,
              ...(phone ? { Téléphone: phone } : {}),
            },
          },
          user: { email, name },
        }),
      });

      const json = await res.json();
      if (json.success) {
        setStatus('success');
        form.reset();
      } else {
        throw new Error(json.error || 'Une erreur est survenue.');
      }
    } catch (err) {
      setStatus('error');
      setErrorMsg(err instanceof Error ? err.message : contact.form.fields.errorLabel);
    }
  }

  return (
    <>
      <Helmet>
        <title>Contact & Réservation — Maroc Surf House Tamraght</title>
        <meta
          name="description"
          content="Contacte Maroc Surf House à Tamraght pour réserver ton séjour surf, poser tes questions sur nos packs ou organiser une excursion. Réponse sous 24h."
        />
        <link rel="canonical" href={pageUrl} />
        <meta property="og:title" content="Contact & Réservation — Maroc Surf House" />
        <meta property="og:description" content="Réserve ton séjour surf à Tamraght, Maroc. On répond sous 24h." />
        <meta property="og:url" content={pageUrl} />
        <meta property="og:type" content="website" />
        <meta property="og:image" content={`${siteUrl}/og-image.svg`} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:image" content={`${siteUrl}/og-image.svg`} />
        <script type="application/ld+json">{JSON.stringify({
          '@context': 'https://schema.org',
          '@graph': [
            {
              '@type': 'ContactPage',
              '@id': `${pageUrl}#webpage`,
              name: 'Contact & Réservation — Maroc Surf House',
              url: pageUrl,
              description: 'Réserve ton séjour surf à Tamraght, Maroc. On répond sous 24h.',
              isPartOf: { '@id': `${siteUrl}/#website` },
            },
            {
              '@type': 'BreadcrumbList',
              '@id': `${pageUrl}#breadcrumb`,
              itemListElement: [
                { '@type': 'ListItem', position: 1, name: 'Accueil', item: siteUrl },
                { '@type': 'ListItem', position: 2, name: 'Contact', item: pageUrl },
              ],
            },
          ],
        }).replace(/</g, '\u003c')}</script>
      </Helmet>

      <main>
        {/* ── HERO ─────────────────────────────────────────────────────────── */}
        <section
          className="relative pt-36 pb-20 px-6 overflow-hidden"
          style={{ background: 'hsl(var(--surface-dark))' }}
        >
          <div className="absolute inset-0 opacity-5 pointer-events-none" aria-hidden="true">
            <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="berber-contact" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
                  <polygon points="20,4 36,20 20,36 4,20" stroke="white" strokeWidth="1" fill="none" />
                  <line x1="20" y1="4" x2="20" y2="36" stroke="white" strokeWidth="0.5" />
                  <line x1="4" y1="20" x2="36" y2="20" stroke="white" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#berber-contact)" />
            </svg>
          </div>

          <div className="relative z-10 text-center max-w-2xl mx-auto">
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-primary text-sm font-semibold tracking-widest uppercase mb-3"
            >
              On est là pour toi
            </motion.p>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.35 }}
              className="text-5xl md:text-6xl font-bold text-white mb-5"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              {contact.hero.title}
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="text-white/65 text-lg"
            >
              {contact.hero.subtitle}
            </motion.p>
          </div>
        </section>

        <div style={{ background: 'hsl(var(--surface-dark))' }}>
          <BerberDivider light />
        </div>

        {/* ── MAIN CONTENT ─────────────────────────────────────────────────── */}
        <section className="py-20 px-6" style={{ background: 'hsl(var(--sand))' }}>
          <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-5 gap-12 items-start">

            {/* ── FORM (3/5) ───────────────────────────────────────────────── */}
            <motion.div
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="lg:col-span-3"
            >
              <div className="rounded-2xl shadow-xl overflow-hidden" style={{ background: 'hsl(var(--surface-dark))' }}>
                <div className="px-8 pt-8 pb-6 border-b border-white/10">
                  <h2
                    className="text-2xl font-bold text-white mb-1"
                    style={{ fontFamily: 'var(--font-heading)' }}
                  >
                    {contact.form.heading}
                  </h2>
                  <p className="text-white/50 text-sm">{contact.form.subheading}</p>
                </div>

                {status === 'success' ? (
                  <div className="px-8 py-16 flex flex-col items-center text-center gap-4">
                    <CheckCircle size={48} className="text-primary" />
                    <h3
                      className="text-2xl font-bold text-white"
                      style={{ fontFamily: 'var(--font-heading)' }}
                    >
                      {contact.form.fields.successHeading}
                    </h3>
                    <p className="text-white/60 text-sm max-w-xs">{contact.form.fields.successBody}</p>
                    <button
                      onClick={() => setStatus('idle')}
                      className="mt-4 text-primary text-sm underline underline-offset-4 hover:text-primary/80 transition-colors"
                    >
                      Envoyer un autre message
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="px-8 py-8 flex flex-col gap-5" noValidate>
                    {/* Honeypot — never included in POST body */}
                    <input
                      type="text"
                      name="_gotcha"
                      tabIndex={-1}
                      autoComplete="off"
                      style={{ position: 'absolute', left: '-9999px' }}
                      aria-hidden="true"
                    />

                    {/* Name + Email */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div className="flex flex-col gap-1.5">
                        <label htmlFor="name" className="text-white/70 text-xs font-medium uppercase tracking-widest">
                          {contact.form.fields.nameLabel} <span className="text-primary">*</span>
                        </label>
                        <input
                          id="name" name="name" type="text" required
                          placeholder={contact.form.fields.namePlaceholder}
                          className="w-full rounded-lg px-4 py-3 text-sm text-white placeholder-white/30 border border-white/10 focus:border-primary focus:outline-none transition-colors"
                          style={{ background: 'hsl(var(--surface-dark) / 0.6)' }}
                        />
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <label htmlFor="email" className="text-white/70 text-xs font-medium uppercase tracking-widest">
                          {contact.form.fields.emailLabel} <span className="text-primary">*</span>
                        </label>
                        <input
                          id="email" name="email" type="email" required
                          placeholder={contact.form.fields.emailPlaceholder}
                          className="w-full rounded-lg px-4 py-3 text-sm text-white placeholder-white/30 border border-white/10 focus:border-primary focus:outline-none transition-colors"
                          style={{ background: 'hsl(var(--surface-dark) / 0.6)' }}
                        />
                      </div>
                    </div>

                    {/* Phone */}
                    <div className="flex flex-col gap-1.5">
                      <label htmlFor="phone" className="text-white/70 text-xs font-medium uppercase tracking-widest">
                        {contact.form.fields.phoneLabel}
                      </label>
                      <input
                        id="phone" name="phone" type="tel"
                        placeholder={contact.form.fields.phonePlaceholder}
                        className="w-full rounded-lg px-4 py-3 text-sm text-white placeholder-white/30 border border-white/10 focus:border-primary focus:outline-none transition-colors"
                        style={{ background: 'hsl(var(--surface-dark) / 0.6)' }}
                      />
                    </div>

                    {/* Pack + Level */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div className="flex flex-col gap-1.5">
                        <label htmlFor="pack" className="text-white/70 text-xs font-medium uppercase tracking-widest">
                          {contact.form.fields.packLabel}
                        </label>
                        <select
                          id="pack" name="pack" defaultValue=""
                          className="w-full rounded-lg px-4 py-3 text-sm text-white border border-white/10 focus:border-primary focus:outline-none transition-colors appearance-none"
                          style={{ background: 'hsl(var(--surface-dark) / 0.8)' }}
                        >
                          <option value="" disabled>Choisir...</option>
                          {selectPacks.map((opt) => (
                            <option key={opt} value={opt}>{opt}</option>
                          ))}
                        </select>
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <label htmlFor="level" className="text-white/70 text-xs font-medium uppercase tracking-widest">
                          {contact.form.fields.levelLabel}
                        </label>
                        <select
                          id="level" name="level" defaultValue=""
                          className="w-full rounded-lg px-4 py-3 text-sm text-white border border-white/10 focus:border-primary focus:outline-none transition-colors appearance-none"
                          style={{ background: 'hsl(var(--surface-dark) / 0.8)' }}
                        >
                          <option value="" disabled>Choisir...</option>
                          {selectLevels.map((opt) => (
                            <option key={opt} value={opt}>{opt}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Dates */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div className="flex flex-col gap-1.5">
                        <label htmlFor="arrival" className="text-white/70 text-xs font-medium uppercase tracking-widest">
                          {contact.form.fields.arrivalLabel}
                        </label>
                        <input
                          id="arrival" name="arrival" type="date"
                          className="w-full rounded-lg px-4 py-3 text-sm text-white/80 border border-white/10 focus:border-primary focus:outline-none transition-colors"
                          style={{ background: 'hsl(var(--surface-dark) / 0.6)', colorScheme: 'dark' }}
                        />
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <label htmlFor="departure" className="text-white/70 text-xs font-medium uppercase tracking-widest">
                          {contact.form.fields.departureLabel}
                        </label>
                        <input
                          id="departure" name="departure" type="date"
                          className="w-full rounded-lg px-4 py-3 text-sm text-white/80 border border-white/10 focus:border-primary focus:outline-none transition-colors"
                          style={{ background: 'hsl(var(--surface-dark) / 0.6)', colorScheme: 'dark' }}
                        />
                      </div>
                    </div>

                    {/* Message */}
                    <div className="flex flex-col gap-1.5">
                      <label htmlFor="message" className="text-white/70 text-xs font-medium uppercase tracking-widest">
                        {contact.form.fields.messageLabel} <span className="text-primary">*</span>
                      </label>
                      <textarea
                        id="message" name="message" required rows={5}
                        placeholder={contact.form.fields.messagePlaceholder}
                        className="w-full rounded-lg px-4 py-3 text-sm text-white placeholder-white/30 border border-white/10 focus:border-primary focus:outline-none transition-colors resize-none"
                        style={{ background: 'hsl(var(--surface-dark) / 0.6)' }}
                      />
                    </div>

                    {status === 'error' && (
                      <p role="alert" className="text-red-400 text-sm">
                        {errorMsg || contact.form.fields.errorLabel}
                      </p>
                    )}

                    <button
                      type="submit"
                      disabled={status === 'sending'}
                      className="w-full py-4 rounded-full bg-primary text-primary-foreground font-bold text-sm tracking-wide hover:bg-primary/90 transition-all duration-200 hover:scale-[1.02] disabled:opacity-60 disabled:cursor-not-allowed disabled:scale-100"
                    >
                      {status === 'sending'
                        ? contact.form.fields.sendingLabel
                        : contact.form.fields.submitLabel}
                    </button>

                    <p className="text-white/30 text-xs text-center">
                      Tes données ne sont jamais partagées avec des tiers.
                    </p>
                  </form>
                )}
              </div>
            </motion.div>

            {/* ── INFO SIDEBAR (2/5) ───────────────────────────────────────── */}
            <motion.div
              variants={stagger}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              className="lg:col-span-2 flex flex-col gap-6"
            >
              {/* Contact info */}
              <motion.div
                variants={fadeUp}
                className="rounded-2xl p-7 shadow-xl"
                style={{ background: 'hsl(var(--surface-dark))' }}
              >
                <h2
                  className="text-xl font-bold text-white mb-5"
                  style={{ fontFamily: 'var(--font-heading)' }}
                >
                  {contact.info.heading}
                </h2>
                <div className="flex flex-col gap-4">
                  <div className="flex items-start gap-3">
                    <MapPin size={16} className="text-primary shrink-0 mt-0.5" />
                    <span className="text-white/65 text-sm">{contact.info.address}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail size={16} className="text-primary shrink-0" />
                    <a
                      href={`mailto:${contact.info.email}`}
                      className="text-white/65 text-sm hover:text-white transition-colors"
                    >
                      {contact.info.email}
                    </a>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone size={16} className="text-primary shrink-0" />
                    <a
                      href={`tel:${contact.info.phone.replace(/\s/g, '')}`}
                      className="text-white/65 text-sm hover:text-white transition-colors"
                    >
                      {contact.info.phone}
                    </a>
                  </div>
                  <div className="flex items-center gap-3">
                    <Clock size={16} className="text-primary shrink-0" />
                    <div className="flex flex-col">
                      <span className="text-white/65 text-sm">{contact.info.responseTime}</span>
                      <span className="text-white/40 text-xs">{contact.info.hours}</span>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Social */}
              <motion.div
                variants={fadeUp}
                className="rounded-2xl p-7 shadow-xl"
                style={{ background: 'hsl(var(--surface-dark))' }}
              >
                <h3
                  className="text-lg font-bold text-white mb-4"
                  style={{ fontFamily: 'var(--font-heading)' }}
                >
                  {contact.social.heading}
                </h3>
                <div className="flex flex-col gap-3">
                  <a
                    href={contact.social.instagram}
                    target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-3 text-white/60 hover:text-white transition-colors group"
                  >
                    <span className="w-9 h-9 rounded-full flex items-center justify-center border border-white/10 group-hover:border-primary group-hover:text-primary transition-colors">
                      <Instagram size={16} />
                    </span>
                    <span className="text-sm">Instagram</span>
                  </a>
                  <a
                    href={contact.social.facebook}
                    target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-3 text-white/60 hover:text-white transition-colors group"
                  >
                    <span className="w-9 h-9 rounded-full flex items-center justify-center border border-white/10 group-hover:border-primary group-hover:text-primary transition-colors">
                      <Facebook size={16} />
                    </span>
                    <span className="text-sm">Facebook</span>
                  </a>
                  <a
                    href={contact.social.youtube}
                    target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-3 text-white/60 hover:text-white transition-colors group"
                  >
                    <span className="w-9 h-9 rounded-full flex items-center justify-center border border-white/10 group-hover:border-primary group-hover:text-primary transition-colors">
                      <Youtube size={16} />
                    </span>
                    <span className="text-sm">YouTube</span>
                  </a>
                </div>
              </motion.div>

              {/* Map */}
              <motion.div
                variants={fadeUp}
                className="rounded-2xl overflow-hidden shadow-xl"
                style={{ background: 'hsl(var(--surface-dark))' }}
              >
                <iframe
                  title="Localisation Maroc Surf House — Tamraght"
                  src="https://www.openstreetmap.org/export/embed.html?bbox=-9.8500%2C30.3200%2C-9.8000%2C30.3600&layer=mapnik&marker=30.3400%2C-9.8250"
                  width="100%"
                  height="220"
                  loading="lazy"
                  className="border-0 w-full"
                  aria-label="Carte OpenStreetMap — Tamraght, Maroc"
                />
                <div className="px-5 py-3">
                  <a
                    href="https://www.openstreetmap.org/?mlat=30.3400&mlon=-9.8250#map=14/30.3400/-9.8250"
                    target="_blank" rel="noopener noreferrer"
                    className="text-primary text-xs hover:underline"
                  >
                    Voir sur OpenStreetMap →
                  </a>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </section>

        <div style={{ background: 'hsl(var(--sand))' }}>
          <BerberDivider />
        </div>
      </main>
    </>
  );
}
