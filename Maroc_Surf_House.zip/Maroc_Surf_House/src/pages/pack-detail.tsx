import { Helmet } from '@dr.pogodin/react-helmet';
import { Link, useParams } from 'react-router';
import { motion } from 'motion/react';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  X,
  Clock,
  Moon,
  UtensilsCrossed,
  BedDouble,
  BarChart2,
  CalendarDays,
  ChevronDown,
  Waves,
  MapPin,
  Users,
  ShieldCheck,
} from 'lucide-react';
import { pack_details } from 'virtual:content';
import { ContentListContext } from '@airo/content';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { useState } from 'react';

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.55, ease: 'easeOut' as const } },
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.1 } } };

const HERO_IMAGES: Record<string, string> = {
  decouverte: '/airo-assets/images/pages/home/pack-decouverte',
  aventure:   '/airo-assets/images/pages/home/pack-aventure',
  premium:    '/airo-assets/images/pages/home/pack-premium',
};


const OVERVIEW_STATS: Record<string, Array<{ icon: string; value: string; label: string }>> = {
  decouverte: [
    { icon: 'waves',  value: '3',     label: 'Sessions de surf' },
    { icon: 'moon',   value: '2',     label: 'Nuits incluses' },
    { icon: 'users',  value: '6 max', label: 'Personnes par groupe' },
    { icon: 'shield', value: '100%',  label: 'Moniteurs certifiés' },
  ],
  aventure: [
    { icon: 'waves',  value: '3',     label: 'Sessions de surf' },
    { icon: 'moon',   value: '4',     label: 'Nuits incluses' },
    { icon: 'map',    value: '2',     label: 'Excursions incluses' },
    { icon: 'users',  value: '8 max', label: 'Personnes par groupe' },
  ],
  premium: [
    { icon: 'waves',  value: '6',     label: 'Cours personnalisés' },
    { icon: 'moon',   value: '6',     label: 'Nuits en suite privée' },
    { icon: 'map',    value: '3',     label: 'Excursions incluses' },
    { icon: 'shield', value: '1h',    label: 'Massage post-surf' },
  ],
};

const OVERVIEW_HIGHLIGHTS: Record<string, Array<{ emoji: string; title: string; desc: string }>> = {
  decouverte: [
    { emoji: 'surf', title: 'Premiers pas sur la vague', desc: "Nos moniteurs certifiés vous accompagnent du premier paddle jusqu'à votre première vague debout." },
    { emoji: 'sunset', title: 'Tamraght, village de surfeurs', desc: "Un village authentique à 15 min d'Agadir, avec des vagues parfaites pour les débutants." },
    { emoji: 'food', title: 'Petit-déjeuner marocain', desc: 'Msemen, argan, thé à la menthe — chaque matin pour bien commencer la journée.' },
  ],
  aventure: [
    { emoji: 'surf', title: 'Surf tous niveaux', desc: 'Groupes par niveau pour que chacun progresse à son rythme, du débutant au confirmé.' },
    { emoji: 'quad', title: 'Quad biking et ferme berbère', desc: "Une excursion unique dans les collines autour de Taghazout avec visite d'une ferme traditionnelle." },
    { emoji: 'meals', title: 'Pension complète', desc: 'Trois repas par jour inclus — petit-déjeuner, déjeuner au bord de la plage et dîner en groupe.' },
  ],
  premium: [
    { emoji: 'video', title: 'Analyse vidéo de votre surf', desc: 'Votre moniteur filme vos sessions. On regarde ensemble pour construire un plan de progression sur mesure.' },
    { emoji: 'suite', title: 'Suite privée vue mer', desc: "Réveillez-vous face à l'Atlantique dans votre suite privée avec vue panoramique sur l'océan." },
    { emoji: 'massage', title: 'Massage post-surf', desc: "Une séance d'1h de massage de récupération musculaire incluse dans votre séjour." },
  ],
};

const siteUrl = 'https://marocsurfhouse.com';

export default function PackDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const [allOpen, setAllOpen] = useState(false);

  return (
    <ContentListContext field="pack_details">
      <>
        {pack_details.map((pack) => {
          const isActive = pack.slug === slug;
          const heroImg = HERO_IMAGES[pack.slug] ?? HERO_IMAGES['aventure'];
          const pageUrl = `${siteUrl}/packs/${pack.slug}`;

          return (
            <div key={pack.id} className={isActive ? '' : 'hidden'} aria-hidden={!isActive}>
              <Helmet>
                <title>{pack.name} — {pack.duration} à Tamraght | Maroc Surf House</title>
                <meta
                  name="description"
                  content={`${pack.name} : ${pack.tagline}. ${pack.duration} à Tamraght dès ${pack.price}${pack.currency}. Cours de surf, hébergement, repas et transferts inclus.`}
                />
                <link rel="canonical" href={pageUrl} />
                <meta property="og:title" content={`${pack.name} — Maroc Surf House`} />
                <meta property="og:description" content={`${pack.tagline}. ${pack.duration} dès ${pack.price}${pack.currency}.`} />
                <meta property="og:url" content={pageUrl} />
                <meta property="og:type" content="website" />
                <meta property="og:image" content={`${siteUrl}/og-image.svg`} />
                <meta name="twitter:card" content="summary_large_image" />
                <meta name="twitter:image" content={`${siteUrl}/og-image.svg`} />
                <script type="application/ld+json">{JSON.stringify({
                  '@context': 'https://schema.org',
                  '@graph': [
                    {
                      '@type': 'Product',
                      '@id': `${pageUrl}#product`,
                      name: pack.name,
                      description: pack.tagline,
                      url: pageUrl,
                      image: `${siteUrl}/og-image.svg`,
                      brand: { '@type': 'Brand', name: 'Maroc Surf House' },
                      offers: {
                        '@type': 'Offer',
                        price: pack.price,
                        priceCurrency: 'EUR',
                        availability: 'https://schema.org/InStock',
                        url: pageUrl,
                        seller: { '@id': `${siteUrl}/#organization` },
                      },
                    },
                    {
                      '@type': 'BreadcrumbList',
                      '@id': `${pageUrl}#breadcrumb`,
                      itemListElement: [
                        { '@type': 'ListItem', position: 1, name: 'Accueil', item: siteUrl },
                        { '@type': 'ListItem', position: 2, name: 'Packs Surf', item: `${siteUrl}/packs` },
                        { '@type': 'ListItem', position: 3, name: pack.name, item: pageUrl },
                      ],
                    },
                  ],
                }).replace(/</g, '\u003c')}</script>
              </Helmet>

              <main>
                {/* ── HERO ─────────────────────────────────────────────── */}
                <section className="relative h-[65vh] min-h-[420px] flex items-end overflow-hidden">
                  <img
                    src={heroImg}
                    alt={pack.heroAlt}
                    className="absolute inset-0 w-full h-full object-cover"
                    loading="eager"
                    fetchPriority="high"
                    width={1920}
                    height={700}
                  />
                  <div
                    className="absolute inset-0 pointer-events-none"
                    style={{ background: 'linear-gradient(to bottom, hsl(var(--surface-dark) / 0.15) 0%, hsl(var(--surface-dark) / 0.85) 65%, hsl(var(--surface-dark)) 100%)' }}
                  />
                  <div className="relative z-10 w-full px-6 pb-14 max-w-5xl mx-auto">
                    <Link
                      to="/packs"
                      className="inline-flex items-center gap-2 text-white/50 hover:text-white text-sm mb-6 transition-colors"
                    >
                      <ArrowLeft size={14} />
                      Tous les packs
                    </Link>
                    <motion.h1
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.55, delay: 0.2 }}
                      className="text-5xl md:text-6xl font-bold text-white mb-3"
                      style={{ fontFamily: 'var(--font-heading)' }}
                    >
                      {pack.name}
                    </motion.h1>
                    <motion.p
                      initial={{ opacity: 0, y: 14 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 0.35 }}
                      className="text-white/60 text-lg mb-6"
                    >
                      {pack.tagline}
                    </motion.p>
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.45, delay: 0.5 }}
                      className="flex flex-wrap gap-2"
                    >
                      <span className="flex items-center gap-1.5 text-xs text-white/60 bg-white/10 backdrop-blur-sm px-3 py-1.5 rounded-full">
                        <Clock size={12} className="text-primary" />{pack.duration}
                      </span>
                      <span className="flex items-center gap-1.5 text-xs text-white/60 bg-white/10 backdrop-blur-sm px-3 py-1.5 rounded-full">
                        <Moon size={12} className="text-primary" />{pack.nights}
                      </span>
                      <span className="flex items-center gap-1.5 text-xs text-white/60 bg-white/10 backdrop-blur-sm px-3 py-1.5 rounded-full">
                        <UtensilsCrossed size={12} className="text-primary" />{pack.meals}
                      </span>
                      <span className="flex items-center gap-1.5 text-xs text-white/60 bg-white/10 backdrop-blur-sm px-3 py-1.5 rounded-full">
                        <BedDouble size={12} className="text-primary" />{pack.accommodation}
                      </span>
                      <span className="flex items-center gap-1.5 text-xs text-white/60 bg-white/10 backdrop-blur-sm px-3 py-1.5 rounded-full">
                        <BarChart2 size={12} className="text-primary" />{pack.level}
                      </span>
                      <span className="flex items-center gap-1.5 text-xs text-white/60 bg-white/10 backdrop-blur-sm px-3 py-1.5 rounded-full">
                        <CalendarDays size={12} className="text-primary" />{pack.season}
                      </span>
                    </motion.div>
                  </div>
                </section>

                {/* ── STICKY PRICE BAR ─────────────────────────────────── */}
                <div
                  className="sticky top-0 z-30 border-b"
                  style={{ background: 'hsl(var(--surface-dark) / 0.95)', backdropFilter: 'blur(12px)', borderColor: 'hsl(var(--border) / 0.15)' }}
                >
                  <div className="max-w-5xl mx-auto px-6 py-3 flex items-center justify-between gap-4">
                    <div className="flex items-baseline gap-3">
                      <span className="text-white/40 line-through text-sm">{pack.priceOriginal}{pack.currency}</span>
                      <span className="text-white font-bold text-2xl" style={{ fontFamily: 'var(--font-heading)' }}>{pack.price}{pack.currency}</span>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={{ background: 'hsl(var(--primary))', color: 'hsl(var(--primary-foreground))' }}>{pack.discount}</span>
                    </div>
                    <Link
                      to="/contact"
                      className="flex items-center gap-2 px-6 py-2.5 rounded-full font-bold text-sm transition-all hover:scale-[1.02]"
                      style={{ background: 'hsl(var(--primary))', color: 'hsl(var(--primary-foreground))' }}
                    >
                      Réserver
                      <ArrowRight size={14} />
                    </Link>
                  </div>
                </div>

                {/* ── OVERVIEW ─────────────────────────────────────────── */}
                <section className="py-16 px-6" style={{ background: 'hsl(var(--card))' }}>
                  <div className="max-w-5xl mx-auto flex flex-col gap-12">
                    {/* Stats chiffres */}
                    <motion.div
                      variants={stagger}
                      initial="hidden"
                      whileInView="visible"
                      viewport={{ once: true }}
                      className="grid grid-cols-2 md:grid-cols-4 gap-4"
                    >
                      {(OVERVIEW_STATS[pack.slug] ?? OVERVIEW_STATS['aventure']).map((stat, i) => (
                        <motion.div
                          key={i}
                          variants={fadeUp}
                          className="flex flex-col items-center text-center gap-2 rounded-2xl p-5"
                          style={{ background: 'hsl(var(--surface-dark))' }}
                        >
                          <div
                            className="w-10 h-10 rounded-full flex items-center justify-center mb-1"
                            style={{ background: 'hsl(var(--primary) / 0.15)' }}
                          >
                            {stat.icon === 'waves'  && <Waves size={18} className="text-primary" />}
                            {stat.icon === 'moon'   && <Moon size={18} className="text-primary" />}
                            {stat.icon === 'users'  && <Users size={18} className="text-primary" />}
                            {stat.icon === 'shield' && <ShieldCheck size={18} className="text-primary" />}
                            {stat.icon === 'map'    && <MapPin size={18} className="text-primary" />}
                          </div>
                          <span className="text-white font-bold text-2xl" style={{ fontFamily: 'var(--font-heading)' }}>{stat.value}</span>
                          <span className="text-white/50 text-xs leading-tight">{stat.label}</span>
                        </motion.div>
                      ))}
                    </motion.div>

                    {/* Points forts */}
                    <div>
                      <motion.h2
                        variants={fadeUp}
                        initial="hidden"
                        whileInView="visible"
                        viewport={{ once: true }}
                        className="text-2xl font-bold text-white mb-6"
                        style={{ fontFamily: 'var(--font-heading)' }}
                      >
                        Ce qui rend ce pack unique
                      </motion.h2>
                      <motion.div
                        variants={stagger}
                        initial="hidden"
                        whileInView="visible"
                        viewport={{ once: true }}
                        className="grid grid-cols-1 md:grid-cols-3 gap-5"
                      >
                        {(OVERVIEW_HIGHLIGHTS[pack.slug] ?? OVERVIEW_HIGHLIGHTS['aventure']).map((h, i) => (
                          <motion.div
                            key={i}
                            variants={fadeUp}
                            className="rounded-2xl p-6 flex flex-col gap-3"
                            style={{ background: 'hsl(var(--surface-dark))', border: '1px solid hsl(var(--border) / 0.12)' }}
                          >
                            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'hsl(var(--primary) / 0.15)' }}>
                              {h.emoji === 'surf'    && <Waves size={20} className="text-primary" />}
                              {h.emoji === 'sunset'  && <MapPin size={20} className="text-primary" />}
                              {h.emoji === 'food'    && <UtensilsCrossed size={20} className="text-primary" />}
                              {h.emoji === 'quad'    && <MapPin size={20} className="text-primary" />}
                              {h.emoji === 'meals'   && <UtensilsCrossed size={20} className="text-primary" />}
                              {h.emoji === 'video'   && <BarChart2 size={20} className="text-primary" />}
                              {h.emoji === 'suite'   && <BedDouble size={20} className="text-primary" />}
                              {h.emoji === 'massage' && <ShieldCheck size={20} className="text-primary" />}
                            </div>
                            <p className="text-white font-semibold text-base" style={{ fontFamily: 'var(--font-heading)' }}>{h.title}</p>
                            <p className="text-white/50 text-sm leading-relaxed">{h.desc}</p>
                          </motion.div>
                        ))}
                      </motion.div>
                    </div>
                  </div>
                </section>

                {/* ── CONTENU PRINCIPAL ────────────────────────────────── */}
                <section className="py-20 px-6" style={{ background: 'hsl(var(--surface-dark))' }}>
                  <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-12">
                    {/* Colonne principale */}
                    <div className="lg:col-span-2 flex flex-col gap-10">
                      {/* Intro */}
                      <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
                        <h2 className="text-2xl font-bold text-white mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
                          Vue d'ensemble
                        </h2>
                        <p className="text-white/60 leading-relaxed">{pack.intro}</p>
                      </motion.div>

                      {/* Itinéraire */}
                      <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
                        <div className="flex items-center justify-between mb-5">
                          <h2 className="text-2xl font-bold text-white" style={{ fontFamily: 'var(--font-heading)' }}>
                            Programme jour par jour
                          </h2>
                          <button
                            onClick={() => setAllOpen((v) => !v)}
                            className="text-xs text-primary hover:underline flex items-center gap-1"
                          >
                            {allOpen ? 'Tout réduire' : 'Tout afficher'}
                            <ChevronDown size={12} className={`transition-transform ${allOpen ? 'rotate-180' : ''}`} />
                          </button>
                        </div>

                        <ContentListContext field={`pack_details.${pack.id}.days`}>
                          <Accordion
                            type="multiple"
                            value={allOpen ? pack.days.map((_, i) => String(i)) : undefined}
                            className="flex flex-col gap-3"
                          >
                            {pack.days.map((day, dayIdx) => (
                              <AccordionItem
                                key={day.id}
                                value={String(dayIdx)}
                                className="rounded-xl border overflow-hidden"
                                style={{ borderColor: 'hsl(var(--border) / 0.15)', background: 'hsl(var(--card))' }}
                              >
                                <AccordionTrigger className="px-6 py-4 hover:no-underline hover:bg-white/5 transition-colors">
                                  <div className="flex items-center gap-4 text-left">
                                    <span
                                      className="text-xs font-bold px-2.5 py-1 rounded-full shrink-0"
                                      style={{ background: 'hsl(var(--primary))', color: 'hsl(var(--primary-foreground))' }}
                                    >
                                      {day.label}
                                    </span>
                                    <span className="text-white font-semibold text-sm">{day.title}</span>
                                  </div>
                                </AccordionTrigger>
                                <AccordionContent className="px-6 pb-5">
                                  <ContentListContext field={`pack_details.${pack.id}.days.${dayIdx}.slots`}>
                                    <ul className="flex flex-col gap-3 pt-2">
                                      {day.slots.map((slot) => (
                                        <li key={slot.id} className="flex items-start gap-4">
                                          <span className="text-primary text-xs font-semibold shrink-0 w-20 pt-0.5">{slot.time}</span>
                                          <span className="text-white/60 text-sm leading-relaxed">{slot.activity}</span>
                                        </li>
                                      ))}
                                    </ul>
                                  </ContentListContext>
                                </AccordionContent>
                              </AccordionItem>
                            ))}
                          </Accordion>
                        </ContentListContext>
                      </motion.div>

                      {/* FAQ */}
                      <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
                        <h2 className="text-2xl font-bold text-white mb-5" style={{ fontFamily: 'var(--font-heading)' }}>
                          Questions fréquentes
                        </h2>
                        <ContentListContext field={`pack_details.${pack.id}.faq`}>
                          <Accordion type="single" collapsible className="flex flex-col gap-3">
                            {pack.faq.map((item, idx) => (
                              <AccordionItem
                                key={item.id}
                                value={String(idx)}
                                className="rounded-xl border px-6"
                                style={{ borderColor: 'hsl(var(--border) / 0.15)', background: 'hsl(var(--card))' }}
                              >
                                <AccordionTrigger className="text-white font-semibold text-sm py-4 hover:no-underline">
                                  {item.question}
                                </AccordionTrigger>
                                <AccordionContent className="text-white/55 text-sm pb-4 leading-relaxed">
                                  {item.answer}
                                </AccordionContent>
                              </AccordionItem>
                            ))}
                          </Accordion>
                        </ContentListContext>
                      </motion.div>
                    </div>

                    {/* Sidebar */}
                    <div className="lg:col-span-1">
                      <motion.div
                        variants={fadeUp}
                        initial="hidden"
                        whileInView="visible"
                        viewport={{ once: true }}
                        className="sticky top-20 flex flex-col gap-6"
                      >
                        {/* Inclus */}
                        <div className="rounded-2xl p-6" style={{ background: 'hsl(var(--card))' }}>
                          <h3 className="text-white font-bold text-base mb-4 flex items-center gap-2" style={{ fontFamily: 'var(--font-heading)' }}>
                            <Check size={16} className="text-primary" />
                            Inclus dans ce pack
                          </h3>
                          <ContentListContext field={`pack_details.${pack.id}.includes`}>
                            <ul className="flex flex-col gap-2.5">
                              {pack.includes.map((item) => (
                                <li key={item.id} className="flex items-start gap-2 text-sm text-white/60">
                                  <Check size={13} className="text-primary shrink-0 mt-0.5" />
                                  <span>{item.text}</span>
                                </li>
                              ))}
                            </ul>
                          </ContentListContext>
                        </div>

                        {/* Non inclus */}
                        <div className="rounded-2xl p-6" style={{ background: 'hsl(var(--card))' }}>
                          <h3 className="text-white font-bold text-base mb-4 flex items-center gap-2" style={{ fontFamily: 'var(--font-heading)' }}>
                            <X size={16} className="text-muted-foreground" />
                            Non inclus
                          </h3>
                          <ContentListContext field={`pack_details.${pack.id}.notIncluded`}>
                            <ul className="flex flex-col gap-2.5">
                              {pack.notIncluded.map((item) => (
                                <li key={item.id} className="flex items-start gap-2 text-sm text-white/60">
                                  <X size={13} className="text-muted-foreground shrink-0 mt-0.5" />
                                  <span>{item.text}</span>
                                </li>
                              ))}
                            </ul>
                          </ContentListContext>
                        </div>

                        {/* CTA */}
                        <div className="rounded-2xl p-6 text-center" style={{ background: 'hsl(var(--primary) / 0.1)', border: '1px solid hsl(var(--primary) / 0.3)' }}>
                          <div className="flex items-baseline justify-center gap-2 mb-1">
                            <span className="text-white/40 line-through text-sm">{pack.priceOriginal}{pack.currency}</span>
                            <span className="text-white font-bold text-3xl" style={{ fontFamily: 'var(--font-heading)' }}>{pack.price}{pack.currency}</span>
                          </div>
                          <p className="text-white/40 text-xs mb-4">par personne · acompte 15%</p>
                          <Link
                            to="/contact"
                            className="w-full flex items-center justify-center gap-2 py-3.5 rounded-full font-bold text-sm transition-all hover:scale-[1.02]"
                            style={{ background: 'hsl(var(--primary))', color: 'hsl(var(--primary-foreground))' }}
                          >
                            Réserver ce pack
                            <ArrowRight size={15} />
                          </Link>
                          <p className="text-white/30 text-xs mt-3">Annulation gratuite jusqu'à 8 jours avant</p>
                        </div>
                      </motion.div>
                    </div>
                  </div>
                </section>

                {/* ── AUTRES PACKS ─────────────────────────────────────── */}
                <section className="py-20 px-6" style={{ background: 'hsl(var(--card))' }}>
                  <div className="max-w-5xl mx-auto">
                    <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="mb-10">
                      <h2 className="text-2xl font-bold text-white" style={{ fontFamily: 'var(--font-heading)' }}>
                        Découvrir nos autres packs
                      </h2>
                    </motion.div>
                    <motion.div
                      variants={stagger}
                      initial="hidden"
                      whileInView="visible"
                      viewport={{ once: true }}
                      className="grid grid-cols-1 sm:grid-cols-2 gap-6"
                    >
                      <ContentListContext field="pack_details">
                        {pack_details.map((other) => (
                          <motion.div key={other.id} variants={fadeUp} className={other.slug === slug ? 'hidden' : ''}>
                            <Link
                              to={`/packs/${other.slug}`}
                              className="group flex gap-5 rounded-2xl p-5 border transition-all hover:border-primary/40"
                              style={{ background: 'hsl(var(--surface-dark))', borderColor: 'hsl(var(--border) / 0.15)' }}
                            >
                              <div className="w-20 h-20 rounded-xl overflow-hidden shrink-0">
                                <img
                                  src={HERO_IMAGES[other.slug] ?? HERO_IMAGES['aventure']}
                                  alt={other.name}
                                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                  loading="lazy"
                                  width={80}
                                  height={80}
                                />
                              </div>
                              <div className="flex flex-col justify-center gap-1 min-w-0">
                                <p className="text-white font-bold text-base truncate" style={{ fontFamily: 'var(--font-heading)' }}>{other.name}</p>
                                <p className="text-white/40 text-xs">{other.duration}</p>
                                <p className="text-primary font-bold text-sm">
                                  {other.price}{other.currency}{' '}
                                  <span className="text-white/30 font-normal line-through text-xs">{other.priceOriginal}{other.currency}</span>
                                </p>
                              </div>
                              <ArrowRight size={16} className="text-white/30 group-hover:text-primary transition-colors shrink-0 self-center ml-auto" />
                            </Link>
                          </motion.div>
                        ))}
                      </ContentListContext>
                    </motion.div>
                  </div>
                </section>
              </main>
            </div>
          );
        })}
      </>
    </ContentListContext>
  );
}
